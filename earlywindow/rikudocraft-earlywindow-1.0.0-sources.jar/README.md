# RikudoCraft — fenêtre précoce (early window)

Ce jar remplace l'écran que NeoForge affiche **avant** le chargement des mods (la fenêtre rouge avec le renard, « NeoForge loading… ») par l'écran de chargement RikudoCraft. Le mod RikudoCraft reprend ensuite la même image, au pixel près, pendant le chargement du jeu.

Ce n'est **pas** un mod. C'est un fournisseur `ImmediateWindowProvider` de FancyModLoader (FML), nommé `rikudocraft`.

## Installation (faite par le launcher RikudoCraft)

1. Le jar est posé dans `mods/`. FML le range dans sa couche SERVICE, parce qu'il déclare `META-INF/services/net.neoforged.neoforgespi.earlywindow.ImmediateWindowProvider`.
2. `config/fml.toml` : `earlyWindowProvider = "rikudocraft"`. Avec `"fmlearlywindow"`, NeoForge reprend sa propre fenêtre et ce jar ne fait rien.
3. Les images, la police ninja et les textes sont lus dans le jar du mod RikudoCraft (`mods/rikudocraft-X.Y.Z.jar`). La police du jeu est lue dans le jar `client-…-extra.jar` des bibliothèques. Ce jar-ci n'embarque **aucune** ressource de Mojang ni de RikudoCraft.

## Sûreté

- Le moindre échec au démarrage déclenche le repli complet sur la vraie fenêtre de NeoForge. C'est le cas si le mod est introuvable, s'il manque une texture, si un shader ne compile pas, ou si la fenêtre ne peut pas être créée. La classe hérite de `DisplayWindow` et lui délègue alors tout.
- `-Drikudocraft.earlywindow.off=true` force ce repli.
- Une erreur de dessin est attrapée : la fenêtre n'affiche plus qu'un fond uni et le jeu continue de charger.
- Ce jar vise FML 4.0.x (NeoForge 21.1.x, Minecraft 1.21.1), testé sur 4.0.41 (NeoForge 21.1.208) et 4.0.42 (NeoForge 21.1.234).

## Origine du code et licence

Ce jar est une œuvre dérivée de **FancyModLoader — module `earlydisplay`** (NeoForged, anciennement Forge Development LLC), distribué sous **GNU LGPL 2.1 uniquement** (`SPDX-License-Identifier: LGPL-2.1-only`) : <https://github.com/neoforged/FancyModLoader>.

Les parties reprises sont la création de la fenêtre GLFW, l'essai des profils OpenGL, le fil de rendu, la passation de la fenêtre à Minecraft (`setupMinecraftWindow`, `positionWindow`, `updateFramebufferSize`), les shaders GLSL 150 et le cadre hors écran. Elles viennent de `DisplayWindow`, `ElementShader`, `EarlyFramebuffer` et `SimpleBufferBuilder` (versions 4.0.41 / 4.0.42). Les fichiers concernés gardent l'en-tête de copyright de Forge Development LLC.

Le dessin de l'écran RikudoCraft (`EarlyScreen`, `EarlyFont`, `EarlyPanorama`, `EarlyText`, `EarlyAssets`, `EarlyJson`) est © 2026 Team Craftou, publié sous la même licence LGPL-2.1-only.

Ce jar est donc distribué sous **LGPL 2.1** : le texte complet est dans `LICENSE`. Son code source est public (jar `-sources` publié à côté, et dossier `src/earlywindow/` du dépôt du mod). Vous pouvez le modifier et le remplacer par votre propre version.
