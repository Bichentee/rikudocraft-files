/*
 * Copyright (c) 2026 Team Craftou
 * SPDX-License-Identifier: LGPL-2.1-only
 *
 * Partie de la fenêtre précoce RikudoCraft, œuvre dérivée de FancyModLoader (earlydisplay, LGPL-2.1-only) : voir README.
 */
package fr.teamcraftou.rikudoearly;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Lecteur JSON minimal (objets → {@link LinkedHashMap} dans l'ordre du fichier, tableaux → {@link List}, nombres → Double,
 * chaînes, booléens, null). Écrit ici pour ne dépendre d'AUCUNE bibliothèque du jeu : la fenêtre précoce tourne avant que
 * Minecraft soit chargé. Toute erreur lève {@link IllegalArgumentException}.
 */
final class EarlyJson {

    private final String s;
    private int i;

    private EarlyJson(String s) {
        this.s = s;
    }

    static Object parse(String text) {
        EarlyJson p = new EarlyJson(text);
        p.ws();
        Object v = p.value();
        p.ws();
        if (p.i != p.s.length()) throw p.err("fin attendue");
        return v;
    }

    @SuppressWarnings("unchecked")
    static Map<String, Object> obj(Object o, String key) {
        if (!(o instanceof Map<?, ?> m)) return null;
        Object v = m.get(key);
        return v instanceof Map<?, ?> ? (Map<String, Object>) v : null;
    }

    static List<?> list(Object o, String key) {
        if (!(o instanceof Map<?, ?> m)) return null;
        Object v = m.get(key);
        return v instanceof List<?> l ? l : null;
    }

    static String str(Object o, String key) {
        if (!(o instanceof Map<?, ?> m)) return null;
        Object v = m.get(key);
        return v instanceof String t ? t : null;
    }

    static int integer(Object o, String key, int def) {
        if (!(o instanceof Map<?, ?> m)) return def;
        Object v = m.get(key);
        return v instanceof Number n ? n.intValue() : def;
    }

    private IllegalArgumentException err(String what) {
        return new IllegalArgumentException("JSON : " + what + " (position " + i + ")");
    }

    private void ws() {
        while (i < s.length()) {
            char c = s.charAt(i);
            if (c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '﻿') i++;
            else break;
        }
    }

    private Object value() {
        if (i >= s.length()) throw err("valeur attendue");
        char c = s.charAt(i);
        switch (c) {
            case '{':
                return object();
            case '[':
                return array();
            case '"':
                return string();
            case 't':
                return lit("true", Boolean.TRUE);
            case 'f':
                return lit("false", Boolean.FALSE);
            case 'n':
                return lit("null", null);
            default:
                return number();
        }
    }

    private Object lit(String word, Object v) {
        if (!s.startsWith(word, i)) throw err("littéral inconnu");
        i += word.length();
        return v;
    }

    private Map<String, Object> object() {
        Map<String, Object> m = new LinkedHashMap<>();
        i++;
        ws();
        if (i < s.length() && s.charAt(i) == '}') {
            i++;
            return m;
        }
        while (true) {
            ws();
            if (i >= s.length() || s.charAt(i) != '"') throw err("clé attendue");
            String k = string();
            ws();
            if (i >= s.length() || s.charAt(i) != ':') throw err("« : » attendu");
            i++;
            ws();
            m.put(k, value());
            ws();
            if (i >= s.length()) throw err("objet non fermé");
            char c = s.charAt(i++);
            if (c == '}') return m;
            if (c != ',') throw err("« , » ou « } » attendu");
        }
    }

    private List<Object> array() {
        List<Object> l = new ArrayList<>();
        i++;
        ws();
        if (i < s.length() && s.charAt(i) == ']') {
            i++;
            return l;
        }
        while (true) {
            ws();
            l.add(value());
            ws();
            if (i >= s.length()) throw err("tableau non fermé");
            char c = s.charAt(i++);
            if (c == ']') return l;
            if (c != ',') throw err("« , » ou « ] » attendu");
        }
    }

    private String string() {
        StringBuilder b = new StringBuilder();
        i++;
        while (true) {
            if (i >= s.length()) throw err("chaîne non fermée");
            char c = s.charAt(i++);
            if (c == '"') return b.toString();
            if (c != '\\') {
                b.append(c);
                continue;
            }
            if (i >= s.length()) throw err("échappement incomplet");
            char e = s.charAt(i++);
            switch (e) {
                case '"', '\\', '/' -> b.append(e);
                case 'b' -> b.append('\b');
                case 'f' -> b.append('\f');
                case 'n' -> b.append('\n');
                case 'r' -> b.append('\r');
                case 't' -> b.append('\t');
                case 'u' -> {
                    if (i + 4 > s.length()) throw err("\\u incomplet");
                    b.append((char) Integer.parseInt(s.substring(i, i + 4), 16));
                    i += 4;
                }
                default -> throw err("échappement inconnu");
            }
        }
    }

    private Double number() {
        int start = i;
        while (i < s.length() && "+-0123456789.eE".indexOf(s.charAt(i)) >= 0) i++;
        if (start == i) throw err("valeur inconnue");
        try {
            return Double.valueOf(s.substring(start, i));
        } catch (NumberFormatException e) {
            throw err("nombre illisible");
        }
    }
}
