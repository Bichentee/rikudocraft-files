/*
 * Copyright (c) 2026 Team Craftou
 * SPDX-License-Identifier: LGPL-2.1-only
 *
 * Partie de la fenêtre précoce RikudoCraft, œuvre dérivée de FancyModLoader (earlydisplay, LGPL-2.1-only) : voir README.
 */
package fr.teamcraftou.rikudoearly;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import org.lwjgl.stb.STBImage;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;

/**
 * Où la fenêtre précoce lit ce qu'elle dessine — SANS rien embarquer de RikudoCraft ni de Mojang dans son propre jar :
 * <ul>
 *   <li>le MOD RikudoCraft (textures du kit laque, logo, police ninja, textes {@code loading/*.json}, panorama de Konoha) :
 *       {@code -Drikudocraft.earlywindow.assets}, sinon les dossiers de mod du développement ({@code MOD_CLASSES} /
 *       {@code fml.modFolders} / {@code fml.modFoldersFile}), sinon le jar {@code rikudocraft-X.Y.Z.jar} du dossier
 *       {@code mods/}, sinon le classpath hérité du développement ; reconnu à {@link #MARKER} ;</li>
 *   <li>la police du JEU (ascii, accents) : le jar {@code client-<mc>-<neoform>-extra.jar} des bibliothèques (même chemin
 *       que {@code ProductionClientProvider} de FML), sinon l'entrée « client-extra » du classpath hérité (développement).
 *       Introuvable → le texte courant n'est pas écrit (tout le reste l'est).</li>
 * </ul>
 */
final class EarlyAssets implements AutoCloseable {

    static final String MARKER = "assets/rikudocraft/loading/en.json";

    /** Une racine de fichiers : un dossier ou un jar. */
    interface Source extends AutoCloseable {
        byte[] read(String path) throws IOException;

        @Override
        void close();
    }

    private record DirSource(Path root) implements Source {
        @Override
        public byte[] read(String path) throws IOException {
            Path p = root.resolve(path);
            return Files.isRegularFile(p) ? Files.readAllBytes(p) : null;
        }

        @Override
        public void close() {}
    }

    private record ZipSource(ZipFile zip) implements Source {
        @Override
        public byte[] read(String path) throws IOException {
            ZipEntry e = zip.getEntry(path);
            if (e == null) return null;
            try (InputStream in = zip.getInputStream(e)) {
                return in.readAllBytes();
            }
        }

        @Override
        public void close() {
            try {
                zip.close();
            } catch (IOException ignored) {
                // rien
            }
        }
    }

    final String modDescription;
    private final Source mod;
    private final Source vanilla;

    private EarlyAssets(Source mod, String modDescription, Source vanilla) {
        this.mod = mod;
        this.modDescription = modDescription;
        this.vanilla = vanilla;
    }

    boolean hasGameFont() {
        return vanilla != null;
    }

    /**
     * Trouve les deux sources. Lève si le MOD est introuvable (sans ses textures, mieux vaut la fenêtre de FML) ; la police
     * du jeu, elle, est facultative.
     */
    static EarlyAssets locate(Path gameDir, Path modsDir, String mcVersion, String neoFormVersion) throws IOException {
        Source mod = null;
        String what = null;
        for (Path p : modCandidates(modsDir)) {
            mod = open(p, MARKER);
            if (mod != null) {
                what = p.toString();
                break;
            }
        }
        if (mod == null) throw new IOException("RikudoCraft introuvable (aucun " + MARKER + ") — mods : " + modsDir);
        Source vanilla = null;
        for (Path p : vanillaCandidates(mcVersion, neoFormVersion)) {
            vanilla = open(p, "assets/minecraft/font/include/default.json");
            if (vanilla != null) break;
        }
        return new EarlyAssets(mod, what, vanilla);
    }

    /** Ouvre {@code p} (dossier ou jar) s'il contient {@code marker}. */
    private static Source open(Path p, String marker) {
        try {
            if (Files.isDirectory(p)) {
                return Files.isRegularFile(p.resolve(marker)) ? new DirSource(p) : null;
            }
            if (Files.isRegularFile(p)) {
                ZipFile z = new ZipFile(p.toFile(), StandardCharsets.UTF_8);
                if (z.getEntry(marker) != null) return new ZipSource(z);
                z.close();
            }
        } catch (IOException | RuntimeException ignored) {
            // illisible : le candidat suivant
        }
        return null;
    }

    private static List<Path> modCandidates(Path modsDir) {
        Set<Path> out = new LinkedHashSet<>();
        String explicit = System.getProperty("rikudocraft.earlywindow.assets");
        if (explicit != null && !explicit.isBlank()) out.add(Paths.get(explicit.trim()));
        // développement : les dossiers du mod (FML les lit dans CommonLaunchHandler.getGroupedModFolders)
        Map<String, List<Path>> folders = modFolders();
        List<Path> ours = folders.remove("rikudocraft");
        if (ours != null) out.addAll(ours);
        folders.values().forEach(out::addAll);
        // en jeu : le jar du dossier mods/
        if (modsDir != null && Files.isDirectory(modsDir)) {
            try (Stream<Path> s = Files.list(modsDir)) {
                List<Path> jars = new ArrayList<>(s.filter(p -> {
                    String n = p.getFileName().toString().toLowerCase();
                    return n.endsWith(".jar") && !n.contains("earlywindow");
                }).sorted().toList());
                jars.sort((a, b) -> Boolean.compare(!isRikudoJar(a), !isRikudoJar(b)));
                out.addAll(jars);
            } catch (IOException ignored) {
                // dossier illisible
            }
        }
        // développement : le classpath hérité (dossiers de ressources)
        for (String e : legacyClassPath()) {
            Path p = Paths.get(e);
            if (Files.isDirectory(p) || p.getFileName().toString().toLowerCase().contains("rikudocraft")) out.add(p);
        }
        return new ArrayList<>(out);
    }

    private static boolean isRikudoJar(Path p) {
        return p.getFileName().toString().toLowerCase().matches("rikudocraft-\\d[\\w.+-]*\\.jar");
    }

    private static List<Path> vanillaCandidates(String mc, String neoForm) {
        List<Path> out = new ArrayList<>();
        String libs = System.getProperty("libraryDirectory");
        if (libs != null && mc != null && neoForm != null) {
            String v = mc + "-" + neoForm;
            out.add(Paths.get(libs, "net", "minecraft", "client", v, "client-" + v + "-extra.jar"));
        }
        for (String e : legacyClassPath()) {
            if (e.contains("client-extra")) out.add(Paths.get(e));
        }
        return out;
    }

    /** {@code legacyClassPath} (BootstrapLauncher) ou le fichier {@code legacyClassPath.file} (développement). */
    private static List<String> legacyClassPath() {
        List<String> out = new ArrayList<>();
        String cp = System.getProperty("legacyClassPath");
        if (cp != null && !cp.isBlank()) {
            for (String s : cp.split(File.pathSeparator)) if (!s.isBlank()) out.add(s);
            return out;
        }
        String file = System.getProperty("legacyClassPath.file");
        if (file != null && !file.isBlank()) {
            try {
                for (String s : Files.readAllLines(Paths.get(file), StandardCharsets.UTF_8)) if (!s.isBlank()) out.add(s.trim());
            } catch (IOException | RuntimeException ignored) {
                // pas de classpath hérité
            }
        }
        return out;
    }

    /** Même lecture que {@code CommonLaunchHandler.getGroupedModFolders} (variable MOD_CLASSES, fml.modFolders, fichier). */
    private static Map<String, List<Path>> modFolders() {
        Map<String, List<Path>> out = new HashMap<>();
        try {
            String file = System.getProperty("fml.modFoldersFile", "");
            if (!file.isEmpty()) {
                Properties p = new Properties();
                try (Reader r = Files.newBufferedReader(Paths.get(file))) {
                    p.load(r);
                }
                for (String id : p.stringPropertyNames()) {
                    for (String s : p.getProperty(id).split(File.pathSeparator)) out.computeIfAbsent(id, k -> new ArrayList<>()).add(Paths.get(s));
                }
                return out;
            }
            String env = System.getenv("MOD_CLASSES");
            String folders = env != null ? env : System.getProperty("fml.modFolders", "");
            for (String entry : folders.split(File.pathSeparator)) {
                if (entry.isBlank()) continue;
                String[] parts = entry.split("%%", 2);
                String id = parts.length == 1 ? "defaultmodid" : parts[0];
                out.computeIfAbsent(id, k -> new ArrayList<>()).add(Paths.get(parts[parts.length - 1]));
            }
        } catch (IOException | RuntimeException ignored) {
            // rien de lisible
        }
        return out;
    }

    /**
     * {@code assets/<ns>/<path>} : pour {@code minecraft}, la surcharge du mod d'abord (le panorama de Konoha), puis le jeu.
     * {@code null} si absent.
     */
    byte[] read(String ns, String path) {
        String full = "assets/" + ns + "/" + path;
        try {
            byte[] b = mod.read(full);
            if (b != null || !"minecraft".equals(ns) || vanilla == null) return b;
            return vanilla.read(full);
        } catch (IOException | RuntimeException e) {
            return null;
        }
    }

    /** Un fichier à la RACINE du mod (son logo, {@code logoFile} de neoforge.mods.toml) ; {@code null} si absent. */
    byte[] readModRoot(String path) {
        try {
            return mod.read(path);
        } catch (IOException | RuntimeException e) {
            return null;
        }
    }

    String readText(String ns, String path) {
        byte[] b = read(ns, path);
        return b == null ? null : new String(b, StandardCharsets.UTF_8);
    }

    /** Une image décodée en RGBA 8 bits (mémoire native de STB : {@link #free()} obligatoire). */
    static final class Image {
        final int w;
        final int h;
        ByteBuffer pixels;

        private Image(int w, int h, ByteBuffer pixels) {
            this.w = w;
            this.h = h;
            this.pixels = pixels;
        }

        /** Alpha du pixel (x, y). */
        int alpha(int x, int y) {
            return pixels.get((y * w + x) * 4 + 3) & 0xFF;
        }

        void free() {
            if (pixels != null) {
                STBImage.stbi_image_free(pixels);
                pixels = null;
            }
        }
    }

    /** Décode un PNG (STB, comme STBHelper de FML) ; {@code null} si illisible. Sans état global : sûr hors du fil du rendu. */
    static Image decode(byte[] png) {
        if (png == null || png.length == 0) return null;
        ByteBuffer src = MemoryUtil.memAlloc(png.length);
        try (MemoryStack stack = MemoryStack.stackPush()) {
            src.put(png).flip();
            var w = stack.mallocInt(1);
            var h = stack.mallocInt(1);
            var c = stack.mallocInt(1);
            ByteBuffer px = STBImage.stbi_load_from_memory(src, w, h, c, 4);
            if (px == null) return null;
            return new Image(w.get(0), h.get(0), px);
        } finally {
            MemoryUtil.memFree(src);
        }
    }

    Image image(String ns, String path) {
        return decode(read(ns, path));
    }

    @Override
    public void close() {
        mod.close();
        if (vanilla != null) vanilla.close();
    }

    // ── options.txt ──────────────────────────────────────────────────────────────────────────────────────────────────────

    /** Les options du jeu qui changent l'image : langue, échelle de l'interface, police Unicode forcée, vitesse du panorama. */
    record Options(String lang, int guiScale, boolean forceUnicode, double panoramaSpeed) {
        static Options read(Path gameDir) {
            Map<String, String> o = new HashMap<>();
            try {
                for (String line : Files.readAllLines(gameDir.resolve("options.txt"), StandardCharsets.UTF_8)) {
                    int k = line.indexOf(':');
                    if (k > 0) o.put(line.substring(0, k), line.substring(k + 1));
                }
            } catch (IOException | RuntimeException ignored) {
                // première ouverture : les défauts du jeu
            }
            return new Options(o.getOrDefault("lang", "en_us"), intOf(o.get("guiScale"), 0),
                    "true".equalsIgnoreCase(o.get("forceUnicodeFont")), doubleOf(o.get("panoramaScrollSpeed"), 1.0));
        }

        private static int intOf(String s, int def) {
            try {
                return s == null ? def : Integer.parseInt(s.trim());
            } catch (NumberFormatException e) {
                return def;
            }
        }

        private static double doubleOf(String s, double def) {
            try {
                return s == null ? def : Double.parseDouble(s.trim());
            } catch (NumberFormatException e) {
                return def;
            }
        }

        /** {@code Window.calculateScale} de Minecraft 1.21.1, à l'identique. */
        int guiScaleFor(int fbW, int fbH) {
            int i = 1;
            while (i != guiScale && i < fbW && i < fbH && fbW / (i + 1) >= 320 && fbH / (i + 1) >= 240) i++;
            if (forceUnicode && i % 2 != 0) i++;
            return i;
        }
    }
}
