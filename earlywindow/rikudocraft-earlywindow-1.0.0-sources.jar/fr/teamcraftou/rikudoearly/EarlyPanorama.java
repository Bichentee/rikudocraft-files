/*
 * Copyright (c) 2026 Team Craftou
 * SPDX-License-Identifier: LGPL-2.1-only
 *
 * Partie de la fenêtre précoce RikudoCraft, œuvre dérivée de FancyModLoader (earlydisplay, LGPL-2.1-only) : voir README.
 */
package fr.teamcraftou.rikudoearly;

/**
 * Le panorama de Konoha, rendu EXACTEMENT comme {@code CubeMap.render} de Minecraft (85°, 4 passes adoucies, faces du mod)
 * avec le BALANCEMENT de {@code PanoramaSwayMixin} : même lacet au même instant (horloge {@code System.nanoTime} partagée
 * avec le jeu, {@code Util.getMillis}). Miroir de {@code client/loading/LoadingPanorama}. Les 6 faces sont décodées sur un
 * fil à part puis téléversées par le fil qui dessine.
 */
final class EarlyPanorama implements AutoCloseable {

    // miroir de PanoramaSwayMixin / LoadingPanorama (sonde verify_1118e)
    private static final double HALF_SPAN_DEG = 115.0;
    private static final double MARGIN_DEG = 3.0;
    private static final double HALF_FOV_RAD = 1.4835298 / 2.0;
    private static final double PERIOD_MS = 80_000.0;
    static final float FADE_IN_MS = 700F;

    private static final float[][][] CORNERS = {
            {{-1, -1, 1}, {-1, 1, 1}, {1, 1, 1}, {1, -1, 1}},
            {{1, -1, 1}, {1, 1, 1}, {1, 1, -1}, {1, -1, -1}},
            {{1, -1, -1}, {1, 1, -1}, {-1, 1, -1}, {-1, -1, -1}},
            {{-1, -1, -1}, {-1, 1, -1}, {-1, 1, 1}, {-1, -1, 1}},
            {{-1, -1, -1}, {-1, -1, 1}, {1, -1, 1}, {1, -1, -1}},
            {{-1, 1, 1}, {-1, 1, -1}, {1, 1, -1}, {1, 1, 1}},
    };
    private static final float[][] UVS = {{0, 0}, {0, 1}, {1, 1}, {1, 0}};

    private final Object lock = new Object();
    private final EarlyAssets assets;
    private EarlyAssets.Image[] decoded;
    private boolean closed;
    private volatile boolean done;
    private final int[] faces = new int[6];
    private boolean uploaded;
    private long readyAtMs = -1L;

    EarlyPanorama(EarlyAssets assets) {
        this.assets = assets;
    }

    void start() {
        Thread t = new Thread(this::decodeAll, "RikudoCraft early panorama");
        t.setDaemon(true);
        t.start();
    }

    /** Les faces sont décodées (ou leur lecture a échoué) : le jar du mod peut être refermé. */
    boolean finished() {
        return done;
    }

    private void decodeAll() {
        EarlyAssets.Image[] imgs = new EarlyAssets.Image[6];
        boolean ok = true;
        try {
            for (int i = 0; i < 6 && ok; i++) {
                imgs[i] = assets.image("minecraft", "textures/gui/title/background/panorama_" + i + ".png");
                ok = imgs[i] != null;
            }
        } catch (Throwable t) {
            ok = false;
        }
        synchronized (lock) {
            if (closed || !ok) {
                for (EarlyAssets.Image im : imgs) if (im != null) im.free();
            } else {
                decoded = imgs;
            }
        }
        done = true;
    }

    /** Fil qui dessine (contexte courant) : téléverse les faces dès qu'elles sont prêtes. */
    void tick() {
        EarlyAssets.Image[] imgs;
        synchronized (lock) {
            if (closed || uploaded || decoded == null) return;
            imgs = decoded;
            decoded = null;
        }
        for (int i = 0; i < 6; i++) faces[i] = EarlyGl.upload(imgs[i]);
        uploaded = true;
        readyAtMs = EarlyScreen.nowMs();
    }

    float fade() {
        if (readyAtMs < 0L) return 0F;
        return Math.max(0F, Math.min(1F, (EarlyScreen.nowMs() - readyAtMs) / FADE_IN_MS));
    }

    /** {@code PanoramaSwayMixin.rikudocraft$swayYaw} (degrés). */
    static float swayYaw(double speed, int fbW, int fbH) {
        if (speed <= 0.0) return 0.0F;
        int w = Math.max(1, fbW);
        int h = Math.max(1, fbH);
        double halfH = Math.toDegrees(Math.atan(Math.tan(HALF_FOV_RAD) * w / h));
        double amp = Math.max(0.0, HALF_SPAN_DEG - halfH - MARGIN_DEG);
        double phase = (EarlyScreen.nowMs() * speed) / PERIOD_MS * (Math.PI * 2.0);
        return (float) (amp * Math.sin(phase));
    }

    /** {@code CubeMap.render(mc, 0, swayYaw, alpha)} sur nos textures, dans le cadre courant. */
    void render(EarlyGl gl, double speed, int fbW, int fbH, float alpha) {
        if (!uploaded || alpha <= 0F) return;
        float yaw = swayYaw(speed, fbW, fbH);
        float[] proj = EarlyGl.perspective(1.4835298F, (float) fbW / (float) Math.max(1, fbH), 0.05F, 10.0F);
        float[] base = EarlyGl.rotationX((float) Math.PI);
        gl.begin3d();
        for (int j = 0; j < 4; j++) {
            float dx = ((float) (j % 2) / 2.0F - 0.5F) / 256.0F;
            float dy = ((float) (j / 2) / 2.0F - 0.5F) / 256.0F;
            float[] mv = EarlyGl.mul(base, EarlyGl.translation(dx, dy, 0F));
            mv = EarlyGl.mul(mv, EarlyGl.rotationX(0F));
            mv = EarlyGl.mul(mv, EarlyGl.rotationY(yaw * (float) (Math.PI / 180.0)));
            float[] mvp = EarlyGl.mul(proj, mv);
            int l = Math.round(255.0F * alpha) / (j + 1);
            for (int k = 0; k < 6; k++) {
                if (faces[k] > 0) gl.face(faces[k], mvp, CORNERS[k], UVS, l / 255F);
            }
        }
        gl.end3d();
    }

    @Override
    public void close() {
        synchronized (lock) {
            closed = true;
            if (decoded != null) {
                for (EarlyAssets.Image im : decoded) if (im != null) im.free();
                decoded = null;
            }
        }
        for (int i = 0; i < 6; i++) {
            EarlyGl.delete(faces[i]);
            faces[i] = 0;
        }
        uploaded = false;
    }
}
