/*
 * Copyright (c) 2026 Team Craftou
 * SPDX-License-Identifier: LGPL-2.1-only
 *
 * Partie de la fenêtre précoce RikudoCraft, œuvre dérivée de FancyModLoader (earlydisplay, LGPL-2.1-only) : voir README.
 */
package fr.teamcraftou.rikudoearly;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Une police BITMAP lue à l'exécution depuis son JSON — MIROIR de {@code client/loading/LoadingFont} (l'écran de chargement
 * en jeu) : mêmes métriques que {@code BitmapProvider} de Minecraft (cellule = image ÷ grille, échelle = height ÷ hauteur
 * de cellule, chasse = dernière colonne opaque + 1 arrondie + 1, haut du glyphe à {@code y + 7 − ascent}), mêmes
 * fournisseurs ({@code bitmap}, {@code space}, {@code reference}), même coupe en lignes. Les deux écrans écrivent donc au
 * pixel près le même texte.
 */
final class EarlyFont implements AutoCloseable {

    private record Glyph(int tex, int texW, int texH, int u, int v, int cw, int ch, float w, float h, float top, float advance) {}

    private final Map<Integer, Glyph> glyphs = new HashMap<>();
    private final Map<Integer, Float> spaces = new HashMap<>();
    private final List<Integer> textures = new ArrayList<>();
    private final EarlyAssets assets;

    private EarlyFont(EarlyAssets assets) {
        this.assets = assets;
    }

    /** {@code ns:path} = {@code assets/ns/font/path.json}. Contexte GL courant (les atlas sont téléversés). Jamais nul. */
    static EarlyFont load(EarlyAssets assets, String ns, String path) {
        EarlyFont f = new EarlyFont(assets);
        f.addFont(ns, path, new HashSet<>(), 0);
        return f;
    }

    boolean isEmpty() {
        return glyphs.isEmpty();
    }

    private void addFont(String ns, String path, Set<String> seen, int depth) {
        if (depth > 4 || !seen.add(ns + ":" + path)) return;
        String json = assets.readText(ns, "font/" + path + ".json");
        if (json == null) return;
        Object root;
        try {
            root = EarlyJson.parse(json);
        } catch (RuntimeException e) {
            return;
        }
        List<?> provs = EarlyJson.list(root, "providers");
        if (provs == null) return;
        for (Object p : provs) {
            String type = EarlyJson.str(p, "type");
            try {
                if ("bitmap".equals(type)) addBitmap(p);
                else if ("space".equals(type)) addSpace(p);
                else if ("reference".equals(type)) {
                    String id = EarlyJson.str(p, "id");
                    if (id != null) {
                        int c = id.indexOf(':');
                        addFont(c < 0 ? "minecraft" : id.substring(0, c), c < 0 ? id : id.substring(c + 1), seen, depth + 1);
                    }
                }
            } catch (RuntimeException ignored) {
                // un fournisseur mal formé n'empêche pas les autres
            }
        }
    }

    private void addSpace(Object p) {
        Map<String, Object> adv = EarlyJson.obj(p, "advances");
        if (adv == null) return;
        for (Map.Entry<String, Object> e : adv.entrySet()) {
            if (e.getKey().isEmpty() || !(e.getValue() instanceof Number n)) continue;
            int cp = e.getKey().codePointAt(0);
            if (!glyphs.containsKey(cp)) spaces.putIfAbsent(cp, n.floatValue());
        }
    }

    private void addBitmap(Object p) {
        String file = EarlyJson.str(p, "file");
        if (file == null) return;
        int c = file.indexOf(':');
        String ns = c < 0 ? "minecraft" : file.substring(0, c);
        String path = c < 0 ? file : file.substring(c + 1);
        int height = EarlyJson.integer(p, "height", 8);
        int ascent = EarlyJson.integer(p, "ascent", 0);
        List<?> rows = EarlyJson.list(p, "chars");
        if (rows == null || rows.isEmpty()) return;
        int[][] grid = new int[rows.size()][];
        for (int i = 0; i < grid.length; i++) grid[i] = String.valueOf(rows.get(i)).codePoints().toArray();
        int cols = grid[0].length;
        if (cols == 0) return;
        EarlyAssets.Image img = assets.image(ns, "textures/" + path);
        if (img == null) return;
        int cw = img.w / cols, ch = img.h / grid.length;
        if (cw <= 0 || ch <= 0) {
            img.free();
            return;
        }
        float scale = (float) height / ch;
        List<int[]> found = new ArrayList<>();
        for (int r = 0; r < grid.length; r++) {
            for (int k = 0; k < grid[r].length && k < cols; k++) {
                int cp = grid[r][k];
                if (cp == 0 || cp == ' ' || glyphs.containsKey(cp) || spaces.containsKey(cp)) continue;
                found.add(new int[]{cp, k, r, actualWidth(img, cw, ch, k, r)});
            }
        }
        int w = img.w, h = img.h;
        int tex = EarlyGl.upload(img);
        if (tex == 0) return;
        textures.add(tex);
        for (int[] g : found) {
            if (glyphs.containsKey(g[0])) continue;
            float adv = (int) (0.5 + g[3] * scale) + 1;
            glyphs.put(g[0], new Glyph(tex, w, h, g[1] * cw, g[2] * ch, cw, ch, cw * scale, ch * scale, 7F - ascent, adv));
        }
    }

    private static int actualWidth(EarlyAssets.Image img, int cw, int ch, int col, int row) {
        for (int i = cw - 1; i >= 0; i--) {
            int x = col * cw + i;
            for (int k = 0; k < ch; k++) {
                if (img.alpha(x, row * ch + k) != 0) return i + 1;
            }
        }
        return 0;
    }

    private Glyph glyph(int cp) {
        Glyph g = glyphs.get(cp);
        return g != null ? g : glyphs.get((int) '?');
    }

    private float advance(int cp) {
        Float sp = spaces.get(cp);
        if (sp != null) return sp;
        if (cp == ' ') return 4F;
        Glyph g = glyph(cp);
        return g == null ? 4F : g.advance;
    }

    int width(String s) {
        float w = 0F;
        for (int i = 0; i < s.length(); ) {
            int cp = s.codePointAt(i);
            w += advance(cp);
            i += Character.charCount(cp);
        }
        return (int) Math.ceil(w);
    }

    /** Écrit {@code s} en (x, y) unités d'interface ({@code scale} pixels chacune) ; rend l'abscisse de fin. */
    float draw(EarlyGl gl, int scale, String s, float x, float y, int argb, float alpha) {
        for (int i = 0; i < s.length(); ) {
            int cp = s.codePointAt(i);
            i += Character.charCount(cp);
            if (!spaces.containsKey(cp) && cp != ' ') {
                Glyph g = glyph(cp);
                if (g != null) {
                    float x0 = x * scale, y0 = (y + g.top) * scale;
                    gl.quad(g.tex, x0, y0, x0 + g.w * scale, y0 + g.h * scale, (float) g.u / g.texW, (float) g.v / g.texH,
                            (float) (g.u + g.cw) / g.texW, (float) (g.v + g.ch) / g.texH, argb, alpha);
                }
            }
            x += advance(cp);
        }
        return x;
    }

    /** Contour plein (8 voisins) puis la lettre à ses couleurs cuites — miroir de {@code LoadingFont.drawOutlined}. */
    void drawOutlined(EarlyGl gl, int scale, String s, float x, float y, int outline, float alpha) {
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                if (dx != 0 || dy != 0) draw(gl, scale, s, x + dx, y + dy, outline, alpha);
            }
        }
        draw(gl, scale, s, x, y, 0xFFFFFFFF, alpha);
    }

    String fit(String s, int maxW) {
        if (width(s) <= maxW) return s;
        String dots = "…";
        int n = s.length();
        while (n > 0 && width(s.substring(0, n).stripTrailing() + dots) > maxW) n--;
        return n <= 0 ? "" : s.substring(0, n).stripTrailing() + dots;
    }

    List<String> wrap(String s, int maxW, int maxLines) {
        List<String> out = new ArrayList<>();
        String[] words = s.trim().split(" +");
        StringBuilder line = new StringBuilder();
        int i = 0;
        while (i < words.length) {
            String cand = line.isEmpty() ? words[i] : line + " " + words[i];
            if (width(cand) <= maxW || line.isEmpty()) {
                line.setLength(0);
                line.append(cand);
                i++;
            } else {
                out.add(line.toString());
                line.setLength(0);
                if (out.size() == maxLines) break;
            }
        }
        if (out.size() < maxLines && !line.isEmpty()) {
            out.add(line.toString());
        } else if (i < words.length || !line.isEmpty()) {
            StringBuilder rest = new StringBuilder(out.remove(out.size() - 1));
            if (!line.isEmpty()) rest.append(' ').append(line);
            for (int k = i; k < words.length; k++) rest.append(' ').append(words[k]);
            out.add(fit(rest.toString(), maxW));
        }
        for (int k = 0; k < out.size(); k++) out.set(k, fit(out.get(k), maxW));
        return out;
    }

    @Override
    public void close() {
        for (int t : textures) EarlyGl.delete(t);
        textures.clear();
        glyphs.clear();
    }
}
