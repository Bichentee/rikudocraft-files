/*
 * Copyright (c) 2026 Team Craftou
 * SPDX-License-Identifier: LGPL-2.1-only
 *
 * Partie de la fenêtre précoce RikudoCraft, œuvre dérivée de FancyModLoader (earlydisplay, LGPL-2.1-only) : voir README.
 */
package fr.teamcraftou.rikudoearly;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Les textes FR / EN — les MÊMES fichiers que l'écran de chargement en jeu ({@code assets/rikudocraft/loading/<fr|en>.json}
 * du mod, lus dans son jar) ; langue = {@code lang} d'options.txt ({@code fr_*} → fr, sinon en) : miroir de
 * {@code client/loading/LoadingText}. Rien n'est écrit en dur ici.
 */
final class EarlyText {

    final String title;
    final String tipLabel;
    final String stageDefault;
    /** Avant la première barre de FML (les toutes premières images). */
    final String stageStart;
    final String percent;
    final String mods;
    final List<String[]> stages = new ArrayList<>();
    final List<String> tips = new ArrayList<>();

    private EarlyText(Object main, Object fallback) {
        title = str(main, fallback, "title");
        tipLabel = str(main, fallback, "tip_label");
        stageDefault = str(main, fallback, "stage_default");
        String start = str(main, fallback, "stage_start");
        stageStart = start.isEmpty() ? stageDefault : start;
        percent = str(main, fallback, "percent");
        mods = str(main, fallback, "mods");
        Map<String, Object> st = EarlyJson.obj(main, "stages");
        if (st == null) st = EarlyJson.obj(fallback, "stages");
        if (st != null) {
            for (Map.Entry<String, Object> e : st.entrySet()) {
                if (e.getValue() instanceof String v) stages.add(new String[]{e.getKey().toLowerCase(Locale.ROOT), v});
            }
        }
        List<?> tl = EarlyJson.list(main, "tips");
        if (tl == null) tl = EarlyJson.list(fallback, "tips");
        if (tl != null) {
            for (Object o : tl) if (o instanceof String s && !s.isBlank()) tips.add(s);
        }
    }

    static String language(String code) {
        String c = code == null ? "en_us" : code.toLowerCase(Locale.ROOT);
        return c.equals("fr") || c.startsWith("fr_") ? "fr" : "en";
    }

    static EarlyText load(EarlyAssets assets, String langCode) {
        String lang = language(langCode);
        Object en = read(assets, "en");
        Object main = "en".equals(lang) ? en : read(assets, lang);
        return new EarlyText(main != null ? main : en, en);
    }

    private static Object read(EarlyAssets assets, String lang) {
        String s = assets.readText("rikudocraft", "loading/" + lang + ".json");
        if (s == null) return null;
        try {
            return EarlyJson.parse(s);
        } catch (RuntimeException e) {
            return null;
        }
    }

    private static String str(Object main, Object fallback, String key) {
        String v = EarlyJson.str(main, key);
        if (v == null) v = EarlyJson.str(fallback, key);
        return v == null ? "" : v;
    }

    /** Libellé d'une étape (préfixe du nom anglais d'une barre ou de l'étiquette de FML) ; {@code null} si inconnue. */
    String stage(String name) {
        if (name == null) return null;
        String n = name.toLowerCase(Locale.ROOT);
        for (String[] s : stages) {
            if (n.startsWith(s[0])) return s[1];
        }
        return null;
    }

    String percent(int value) {
        return percent.replace("{0}", Integer.toString(value));
    }

    String mods(int done, int total) {
        return mods.replace("{0}", Integer.toString(done)).replace("{1}", Integer.toString(total));
    }
}
