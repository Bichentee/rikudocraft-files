/*
 * Copyright (c) Forge Development LLC and contributors
 * Copyright (c) 2026 Team Craftou (modifications : rendu de l'écran RikudoCraft)
 * SPDX-License-Identifier: LGPL-2.1-only
 *
 * Dérivé de net.neoforged.fml.earlydisplay.ElementShader / EarlyFramebuffer / SimpleBufferBuilder (FancyModLoader 4.0.41 /
 * 4.0.42, LGPL-2.1-only) : mêmes shaders GLSL 150 core, même cadre hors écran retourné, même recopie par glBlitFramebuffer.
 */
package fr.teamcraftou.rikudoearly;

import static org.lwjgl.opengl.GL32C.*;

import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import org.lwjgl.system.MemoryUtil;

/**
 * Le rendu OpenGL (cœur 3.2) de la fenêtre précoce : deux programmes (2D de FML enrichi d'une teinte, et le cube du
 * panorama), un tampon de sommets dynamique, des textures au plus proche, et le CADRE HORS ÉCRAN à la taille de la fenêtre
 * (comme {@code EarlyFramebuffer} : retourné verticalement, recopié vers la fenêtre par {@code glBlitFramebuffer}). C'est
 * ce cadre que {@code NeoForgeLoadingOverlay} — et l'écran de chargement en jeu de RikudoCraft — reprennent au passage de
 * relais ({@code getFramebufferTextureId}).
 *
 * <p>Après la passation de la fenêtre à Minecraft, on dessine sur le fil principal, au milieu de l'initialisation du jeu :
 * {@link Snapshot} relève tout l'état GL que l'on touche et le rend à l'identique (les caches de {@code GlStateManager}
 * restent justes).</p>
 */
final class EarlyGl implements AutoCloseable {

    private static final int FLOATS_2D = 8; // x y u v r g b a
    private static final int FLOATS_3D = 9; // x y z u v r g b a
    private static final int MAX_VERTS = 6 * 4096;

    private int prog2d;
    private int u2dScreen;
    private int u2dTex;
    private int u2dType;
    private int prog3d;
    private int u3dMvp;
    private int u3dTex;
    private int vao2d;
    private int vbo2d;
    private int vao3d;
    private int vbo3d;
    private FloatBuffer verts;
    private int count;
    private int boundTex = Integer.MIN_VALUE;
    private int screenW = 1;
    private int screenH = 1;

    private int fbo;
    private int fboTex;
    private int fboW;
    private int fboH;

    /** Contexte courant obligatoire. Lève si un shader ne compile pas (l'appelant retombe sur la fenêtre de FML). */
    void init() {
        prog2d = program("""
                #version 150 core
                in vec2 position;
                in vec2 tex;
                in vec4 colour;
                uniform vec2 screenSize;
                out vec2 fTex;
                out vec4 fColour;
                void main() {
                    fTex = tex;
                    fColour = colour;
                    gl_Position = vec4((position/screenSize) * 2 - 1, 0.0, 1.0);
                }
                """, """
                #version 150 core
                uniform sampler2D tex;
                uniform int rendertype;
                in vec2 fTex;
                in vec4 fColour;
                out vec4 fragColor;
                void main() {
                    if (rendertype == 1)
                        fragColor = texture(tex, fTex) * fColour;
                    else
                        fragColor = fColour;
                }
                """, false);
        u2dScreen = glGetUniformLocation(prog2d, "screenSize");
        u2dTex = glGetUniformLocation(prog2d, "tex");
        u2dType = glGetUniformLocation(prog2d, "rendertype");
        prog3d = program("""
                #version 150 core
                in vec3 position;
                in vec2 tex;
                in vec4 colour;
                uniform mat4 mvp;
                out vec2 fTex;
                out vec4 fColour;
                void main() {
                    fTex = tex;
                    fColour = colour;
                    vec4 p = mvp * vec4(position, 1.0);
                    gl_Position = vec4(p.x, -p.y, p.z, p.w);
                }
                """, """
                #version 150 core
                uniform sampler2D tex;
                in vec2 fTex;
                in vec4 fColour;
                out vec4 fragColor;
                void main() {
                    fragColor = texture(tex, fTex) * fColour;
                }
                """, true);
        u3dMvp = glGetUniformLocation(prog3d, "mvp");
        u3dTex = glGetUniformLocation(prog3d, "tex");
        verts = MemoryUtil.memAllocFloat(MAX_VERTS * FLOATS_3D);
        vao2d = glGenVertexArrays();
        vbo2d = glGenBuffers();
        glBindVertexArray(vao2d);
        glBindBuffer(GL_ARRAY_BUFFER, vbo2d);
        glVertexAttribPointer(0, 2, GL_FLOAT, false, FLOATS_2D * 4, 0);
        glVertexAttribPointer(1, 2, GL_FLOAT, false, FLOATS_2D * 4, 8);
        glVertexAttribPointer(2, 4, GL_FLOAT, false, FLOATS_2D * 4, 16);
        glEnableVertexAttribArray(0);
        glEnableVertexAttribArray(1);
        glEnableVertexAttribArray(2);
        vao3d = glGenVertexArrays();
        vbo3d = glGenBuffers();
        glBindVertexArray(vao3d);
        glBindBuffer(GL_ARRAY_BUFFER, vbo3d);
        glVertexAttribPointer(0, 3, GL_FLOAT, false, FLOATS_3D * 4, 0);
        glVertexAttribPointer(1, 2, GL_FLOAT, false, FLOATS_3D * 4, 12);
        glVertexAttribPointer(2, 4, GL_FLOAT, false, FLOATS_3D * 4, 20);
        glEnableVertexAttribArray(0);
        glEnableVertexAttribArray(1);
        glEnableVertexAttribArray(2);
        glBindVertexArray(0);
        glBindBuffer(GL_ARRAY_BUFFER, 0);
    }

    private static int program(String vs, String fs, boolean threeD) {
        int v = glCreateShader(GL_VERTEX_SHADER);
        int f = glCreateShader(GL_FRAGMENT_SHADER);
        glShaderSource(v, vs);
        glShaderSource(f, fs);
        glCompileShader(v);
        if (glGetShaderi(v, GL_COMPILE_STATUS) == GL_FALSE) throw new IllegalStateException("vertex shader : " + glGetShaderInfoLog(v));
        glCompileShader(f);
        if (glGetShaderi(f, GL_COMPILE_STATUS) == GL_FALSE) throw new IllegalStateException("fragment shader : " + glGetShaderInfoLog(f));
        int p = glCreateProgram();
        glBindAttribLocation(p, 0, "position");
        glBindAttribLocation(p, 1, "tex");
        glBindAttribLocation(p, 2, "colour");
        glAttachShader(p, v);
        glAttachShader(p, f);
        glLinkProgram(p);
        if (glGetProgrami(p, GL_LINK_STATUS) == GL_FALSE) throw new IllegalStateException("programme : " + glGetProgramInfoLog(p));
        glDetachShader(p, v);
        glDetachShader(p, f);
        glDeleteShader(v);
        glDeleteShader(f);
        return p;
    }

    // ── textures ─────────────────────────────────────────────────────────────────────────────────────────────────────────

    /** Une texture RGBA au plus proche (comme les textures du jeu sans .mcmeta) ; libère l'image. 0 si {@code img} est nul. */
    static int upload(EarlyAssets.Image img) {
        if (img == null) return 0;
        try {
            int id = glGenTextures();
            glActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D, id);
            glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
            glPixelStorei(GL_UNPACK_ROW_LENGTH, 0);
            glPixelStorei(GL_UNPACK_SKIP_PIXELS, 0);
            glPixelStorei(GL_UNPACK_SKIP_ROWS, 0);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, img.w, img.h, 0, GL_RGBA, GL_UNSIGNED_BYTE, img.pixels);
            glBindTexture(GL_TEXTURE_2D, 0);
            return id;
        } finally {
            img.free();
        }
    }

    static void delete(int tex) {
        if (tex > 0) glDeleteTextures(tex);
    }

    // ── le cadre hors écran ──────────────────────────────────────────────────────────────────────────────────────────────

    /** (Re)crée le cadre à la taille de la fenêtre et le prend pour cible. */
    void bindFramebuffer(int w, int h) {
        if (fbo == 0 || w != fboW || h != fboH) {
            deleteFramebuffer();
            fbo = glGenFramebuffers();
            fboTex = glGenTextures();
            glBindFramebuffer(GL_FRAMEBUFFER, fbo);
            glActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D, fboTex);
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, (ByteBuffer) null);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
            glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, fboTex, 0);
            glBindTexture(GL_TEXTURE_2D, 0);
            if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE) {
                glBindFramebuffer(GL_FRAMEBUFFER, 0);
                deleteFramebuffer();
                throw new IllegalStateException("cadre hors écran incomplet");
            }
            fboW = w;
            fboH = h;
        }
        glBindFramebuffer(GL_FRAMEBUFFER, fbo);
        glViewport(0, 0, w, h);
    }

    /** Recopie le cadre vers la fenêtre (source retournée, comme {@code EarlyFramebuffer.draw}). */
    void presentToWindow(int winFbW, int winFbH) {
        if (fbo == 0) return;
        glBindFramebuffer(GL_DRAW_FRAMEBUFFER, 0);
        glBindFramebuffer(GL_READ_FRAMEBUFFER, fbo);
        glViewport(0, 0, winFbW, winFbH);
        glClearColor(EarlyScreen.r(EarlyScreen.NIGHT), EarlyScreen.g(EarlyScreen.NIGHT), EarlyScreen.b(EarlyScreen.NIGHT), 1F);
        glClear(GL_COLOR_BUFFER_BIT);
        glBlitFramebuffer(0, fboH, fboW, 0, 0, 0, Math.min(fboW, winFbW), Math.min(fboH, winFbH), GL_COLOR_BUFFER_BIT, GL_NEAREST);
        glBindFramebuffer(GL_FRAMEBUFFER, 0);
    }

    int framebufferTexture() {
        return fboTex;
    }

    int framebufferWidth() {
        return fboW;
    }

    int framebufferHeight() {
        return fboH;
    }

    private void deleteFramebuffer() {
        if (fboTex != 0) glDeleteTextures(fboTex);
        if (fbo != 0) glDeleteFramebuffers(fbo);
        fbo = 0;
        fboTex = 0;
        fboW = 0;
        fboH = 0;
    }

    // ── 2D ───────────────────────────────────────────────────────────────────────────────────────────────────────────────

    /** Commence une passe 2D en PIXELS de la cible ({@code w × h}), état des menus du jeu : mélange alpha, sans profondeur. */
    void begin2d(int w, int h) {
        screenW = Math.max(1, w);
        screenH = Math.max(1, h);
        glDisable(GL_DEPTH_TEST);
        glDisable(GL_CULL_FACE);
        glDisable(GL_SCISSOR_TEST);
        glEnable(GL_BLEND);
        // couleur : le mélange par défaut de Minecraft ; alpha : il reste à 1 sur un fond opaque (le cadre est repris tel quel)
        glBlendFuncSeparate(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA, GL_ONE, GL_ONE_MINUS_SRC_ALPHA);
        glColorMask(true, true, true, true);
        glUseProgram(prog2d);
        glUniform2f(u2dScreen, screenW, screenH);
        glUniform1i(u2dTex, 0);
        glActiveTexture(GL_TEXTURE0);
        glBindVertexArray(vao2d);
        glBindBuffer(GL_ARRAY_BUFFER, vbo2d);
        count = 0;
        boundTex = Integer.MIN_VALUE;
        verts.clear();
    }

    /** Un quad 2D (pixels), texture {@code tex} (0 = couleur unie) et teinte ARGB déjà multipliée par l'opacité. */
    void quad(int tex, float x0, float y0, float x1, float y1, float u0, float v0, float u1, float v1, int argb, float alpha) {
        float a = ((argb >>> 24) & 0xFF) / 255F * Math.max(0F, Math.min(1F, alpha));
        if (a <= 0F || x1 <= x0 || y1 <= y0) return;
        if (tex != boundTex) {
            flush2d();
            boundTex = tex;
        }
        if (count + 6 > MAX_VERTS) flush2d();
        float r = ((argb >> 16) & 0xFF) / 255F, g = ((argb >> 8) & 0xFF) / 255F, b = (argb & 0xFF) / 255F;
        v2(x0, y0, u0, v0, r, g, b, a);
        v2(x0, y1, u0, v1, r, g, b, a);
        v2(x1, y1, u1, v1, r, g, b, a);
        v2(x0, y0, u0, v0, r, g, b, a);
        v2(x1, y1, u1, v1, r, g, b, a);
        v2(x1, y0, u1, v0, r, g, b, a);
    }

    private void v2(float x, float y, float u, float v, float r, float g, float b, float a) {
        verts.put(x).put(y).put(u).put(v).put(r).put(g).put(b).put(a);
        count++;
    }

    void flush2d() {
        if (count == 0) return;
        verts.flip();
        glBindTexture(GL_TEXTURE_2D, boundTex > 0 ? boundTex : 0);
        glUniform1i(u2dType, boundTex > 0 ? 1 : 2);
        glBufferData(GL_ARRAY_BUFFER, verts, GL_STREAM_DRAW);
        glDrawArrays(GL_TRIANGLES, 0, count);
        verts.clear();
        count = 0;
    }

    void end2d() {
        flush2d();
        glBindTexture(GL_TEXTURE_2D, 0);
    }

    // ── 3D (le cube du panorama) ─────────────────────────────────────────────────────────────────────────────────────────

    void begin3d() {
        flush2d();
        glUseProgram(prog3d);
        glUniform1i(u3dTex, 0);
        glActiveTexture(GL_TEXTURE0);
        glBindVertexArray(vao3d);
        glBindBuffer(GL_ARRAY_BUFFER, vbo3d);
        verts.clear();
    }

    /** Une face (4 sommets dans l'ordre de {@code CubeMap.render}), en 2 triangles. */
    void face(int tex, float[] mvp, float[][] corners, float[][] uvs, float alpha) {
        verts.clear();
        int[] order = {0, 1, 2, 0, 2, 3};
        for (int k : order) {
            verts.put(corners[k][0]).put(corners[k][1]).put(corners[k][2]).put(uvs[k][0]).put(uvs[k][1])
                    .put(1F).put(1F).put(1F).put(alpha);
        }
        verts.flip();
        glUniformMatrix4fv(u3dMvp, false, mvp);
        glBindTexture(GL_TEXTURE_2D, tex);
        glBufferData(GL_ARRAY_BUFFER, verts, GL_STREAM_DRAW);
        glDrawArrays(GL_TRIANGLES, 0, 6);
        verts.clear();
    }

    /** Revient en 2D après le cube. */
    void end3d() {
        glBindTexture(GL_TEXTURE_2D, 0);
        glUseProgram(prog2d);
        glUniform2f(u2dScreen, screenW, screenH);
        glUniform1i(u2dTex, 0);
        glBindVertexArray(vao2d);
        glBindBuffer(GL_ARRAY_BUFFER, vbo2d);
        count = 0;
        boundTex = Integer.MIN_VALUE;
        verts.clear();
    }

    @Override
    public void close() {
        deleteFramebuffer();
        if (vbo2d != 0) glDeleteBuffers(vbo2d);
        if (vbo3d != 0) glDeleteBuffers(vbo3d);
        if (vao2d != 0) glDeleteVertexArrays(vao2d);
        if (vao3d != 0) glDeleteVertexArrays(vao3d);
        if (prog2d != 0) glDeleteProgram(prog2d);
        if (prog3d != 0) glDeleteProgram(prog3d);
        vbo2d = vbo3d = vao2d = vao3d = prog2d = prog3d = 0;
        if (verts != null) {
            MemoryUtil.memFree(verts);
            verts = null;
        }
    }

    // ── matrices (colonne par colonne, comme JOML / glUniformMatrix4fv) ─────────────────────────────────────────────────

    static float[] identity() {
        return new float[]{1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1};
    }

    /** {@code Matrix4f.setPerspective(fovy, aspect, near, far)} (OpenGL, z dans [-1, 1]). */
    static float[] perspective(float fovy, float aspect, float near, float far) {
        float f = (float) (1.0 / Math.tan(fovy * 0.5));
        float[] m = new float[16];
        m[0] = f / aspect;
        m[5] = f;
        m[10] = (far + near) / (near - far);
        m[11] = -1F;
        m[14] = (far + far) * near / (near - far);
        return m;
    }

    static float[] rotationX(float a) {
        float c = (float) Math.cos(a), s = (float) Math.sin(a);
        return new float[]{1, 0, 0, 0, 0, c, s, 0, 0, -s, c, 0, 0, 0, 0, 1};
    }

    static float[] rotationY(float a) {
        float c = (float) Math.cos(a), s = (float) Math.sin(a);
        return new float[]{c, 0, -s, 0, 0, 1, 0, 0, s, 0, c, 0, 0, 0, 0, 1};
    }

    static float[] translation(float x, float y, float z) {
        return new float[]{1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, x, y, z, 1};
    }

    /** {@code a × b}. */
    static float[] mul(float[] a, float[] b) {
        float[] o = new float[16];
        for (int c = 0; c < 4; c++) {
            for (int r = 0; r < 4; r++) {
                float s = 0;
                for (int k = 0; k < 4; k++) s += a[k * 4 + r] * b[c * 4 + k];
                o[c * 4 + r] = s;
            }
        }
        return o;
    }

    // ── l'état GL que l'on touche, relevé et rendu (après la passation) ──────────────────────────────────────────────────

    static final class Snapshot {
        private final int program;
        private final int vao;
        private final int arrayBuffer;
        private final int activeTexture;
        private final int tex0;
        private final int drawFb;
        private final int readFb;
        private final int[] viewport = new int[4];
        private final float[] clear = new float[4];
        private final boolean blend;
        private final boolean depth;
        private final boolean cull;
        private final boolean scissor;
        private final int srcRgb;
        private final int dstRgb;
        private final int srcA;
        private final int dstA;
        private final int[] colorMask = new int[4];
        private final int unpackAlign;
        private final int unpackRow;
        private final int unpackSkipPx;
        private final int unpackSkipRows;

        Snapshot() {
            program = glGetInteger(GL_CURRENT_PROGRAM);
            vao = glGetInteger(GL_VERTEX_ARRAY_BINDING);
            arrayBuffer = glGetInteger(GL_ARRAY_BUFFER_BINDING);
            activeTexture = glGetInteger(GL_ACTIVE_TEXTURE);
            glActiveTexture(GL_TEXTURE0);
            tex0 = glGetInteger(GL_TEXTURE_BINDING_2D);
            drawFb = glGetInteger(GL_DRAW_FRAMEBUFFER_BINDING);
            readFb = glGetInteger(GL_READ_FRAMEBUFFER_BINDING);
            glGetIntegerv(GL_VIEWPORT, viewport);
            glGetFloatv(GL_COLOR_CLEAR_VALUE, clear);
            blend = glIsEnabled(GL_BLEND);
            depth = glIsEnabled(GL_DEPTH_TEST);
            cull = glIsEnabled(GL_CULL_FACE);
            scissor = glIsEnabled(GL_SCISSOR_TEST);
            srcRgb = glGetInteger(GL_BLEND_SRC_RGB);
            dstRgb = glGetInteger(GL_BLEND_DST_RGB);
            srcA = glGetInteger(GL_BLEND_SRC_ALPHA);
            dstA = glGetInteger(GL_BLEND_DST_ALPHA);
            glGetIntegerv(GL_COLOR_WRITEMASK, colorMask);
            unpackAlign = glGetInteger(GL_UNPACK_ALIGNMENT);
            unpackRow = glGetInteger(GL_UNPACK_ROW_LENGTH);
            unpackSkipPx = glGetInteger(GL_UNPACK_SKIP_PIXELS);
            unpackSkipRows = glGetInteger(GL_UNPACK_SKIP_ROWS);
        }

        void restore() {
            glUseProgram(program);
            glBindVertexArray(vao);
            glBindBuffer(GL_ARRAY_BUFFER, arrayBuffer);
            glActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D, tex0);
            glActiveTexture(activeTexture);
            glBindFramebuffer(GL_DRAW_FRAMEBUFFER, drawFb);
            glBindFramebuffer(GL_READ_FRAMEBUFFER, readFb);
            glViewport(viewport[0], viewport[1], viewport[2], viewport[3]);
            glClearColor(clear[0], clear[1], clear[2], clear[3]);
            set(GL_BLEND, blend);
            set(GL_DEPTH_TEST, depth);
            set(GL_CULL_FACE, cull);
            set(GL_SCISSOR_TEST, scissor);
            glBlendFuncSeparate(srcRgb, dstRgb, srcA, dstA);
            glColorMask(colorMask[0] != 0, colorMask[1] != 0, colorMask[2] != 0, colorMask[3] != 0);
            glPixelStorei(GL_UNPACK_ALIGNMENT, unpackAlign);
            glPixelStorei(GL_UNPACK_ROW_LENGTH, unpackRow);
            glPixelStorei(GL_UNPACK_SKIP_PIXELS, unpackSkipPx);
            glPixelStorei(GL_UNPACK_SKIP_ROWS, unpackSkipRows);
        }

        private static void set(int cap, boolean on) {
            if (on) glEnable(cap);
            else glDisable(cap);
        }
    }
}
