/*
 * Copyright (c) 2026 Team Craftou
 * SPDX-License-Identifier: LGPL-2.1-only
 *
 * Partie de la fenêtre précoce RikudoCraft, œuvre dérivée de FancyModLoader (earlydisplay, LGPL-2.1-only) : voir README.
 */
package fr.teamcraftou.rikudoearly;

import java.util.List;
import net.neoforged.fml.loading.progress.ProgressMeter;
import net.neoforged.fml.loading.progress.StartupNotificationManager;

/**
 * <h2>⚠⚠ 11-18e — l'écran de la FENÊTRE PRÉCOCE, au pixel près celui du jeu</h2>
 *
 * <p>MIROIR de {@code client/loading/LoadingScreenArt} (l'écran de chargement RikudoCraft en jeu) : mêmes constantes, même
 * mise en page en unités d'interface (échelle = {@code Window.calculateScale} sur les options du joueur), mêmes pièces du kit
 * laque lues dans le jar du mod, même police, même panorama balancé au même instant, même astuce au même instant. Quand le
 * jeu reprend la fenêtre, l'image ne change pas — seul le libellé de l'étape avance. La sonde verify_1118e compare les
 * constantes des deux fichiers.</p>
 */
final class EarlyScreen implements AutoCloseable {

    // ── mise en page (unités d'interface) — IDENTIQUE à LoadingScreenArt ──
    static final int LOGO_W = 100, LOGO_H = 40;
    static final int PANEL_MAX_W = 300, SIDE = 16, B = 10, FRAME_EDGE = 19, OVER = 8, PAD = 6, MIN_GAP = 4;
    static final int ROW1_Y = 19, BAR_Y = 32, BAR_H = 14, SEP_Y = 53, TIP_LABEL_Y = 63, TIP_Y = 75, LINE_H = 10;
    static final int PANEL_H = 108, PANEL_H_COMPACT = 62, TIP_LINES = 2;
    static final int BG_TILE = 48;

    // ── couleurs (LacquerUi) — IDENTIQUES ──
    static final int OUTLINE = 0xFF1A0E0A, TEXT = 0xFFECDDBE, TEXT_SOFT = 0xFFB4A68C, SEP_DARK = 0xFF14100E,
            SEP_LIGHT = 0xFF4A4038, SHADOW = 0x6E000000;
    static final int NIGHT = 0xFF0B0A12, VEIL = 0xA60B0A12;

    // ── astuces : le MÊME calendrier que l'écran en jeu (RikudoLoadingOverlay.tipAt) ──
    static final long TIP_MS = 7000L, TIP_FADE_MS = 350L;

    /** La progression montrée ici couvre [0 ; PHASE_A_MAX] ; l'écran en jeu repart de la valeur atteinte. */
    static final float PHASE_A_MAX = 0.30F;

    /** Repères de FML (étiquette de la barre EARLY ou nom d'une barre, en minuscules) → avancement. */
    private static final Object[][] MILESTONES = {
            {"bootstrapping", 0.02F}, {"loading bootstrap resources", 0.04F}, {"discovering mod files", 0.06F},
            {"found ", 0.08F}, {"scanning mod candidates", 0.10F}, {"loading language providers", 0.12F},
            {"loaded language provider", 0.13F}, {"launching minecraft", 0.15F}, {"initializing game graphics", 0.18F},
            {"loading mods", 0.20F}, {"mod construction", 0.21F}, {"registry initialization", 0.28F}, {"config loading", 0.29F},
    };
    /** Part de la barre « Mod Construction » (au prorata des mods construits). */
    private static final float CONSTRUCTION_SPAN = 0.06F;

    private record Tex(int id, int w, int h) {}

    private final EarlyAssets.Options options;
    private final EarlyText text;
    private final EarlyFont ninja;
    private final EarlyFont body;
    private final EarlyPanorama panorama;
    private final Tex frame, seigaiha, plaque, cell, barFill, logo;

    private float target;
    private float shown;
    private String lastStage;

    /** Contexte GL courant. Lève si l'essentiel manque (cadre, police ninja) : on retombe alors sur la fenêtre de FML. */
    EarlyScreen(EarlyAssets assets, EarlyAssets.Options options) {
        this.options = options;
        this.text = EarlyText.load(assets, options.lang());
        frame = tex(assets, "textures/gui/hub/frame.png");
        seigaiha = tex(assets, "textures/gui/hub/seigaiha.png");
        plaque = tex(assets, "textures/gui/hub/plaque.png");
        cell = tex(assets, "textures/gui/hub/cell.png");
        barFill = tex(assets, "textures/gui/loading/bar_fill.png");
        logo = tex(assets, "textures/gui/rikudocraft.png");
        ninja = EarlyFont.load(assets, "rikudocraft", "ninja");
        body = EarlyFont.load(assets, "minecraft", "default");
        panorama = new EarlyPanorama(assets);
        if (frame == null || logo == null || ninja.isEmpty()) {
            close();
            throw new IllegalStateException("pièces de l'écran introuvables dans " + assets.modDescription);
        }
        panorama.start();
    }

    private static Tex tex(EarlyAssets assets, String path) {
        EarlyAssets.Image img = assets.image("rikudocraft", path);
        if (img == null) return null;
        int w = img.w, h = img.h;
        int id = EarlyGl.upload(img);
        return id == 0 ? null : new Tex(id, w, h);
    }

    boolean panoramaFinished() {
        return panorama.finished();
    }

    /** L'avancement montré (pour le passage de relais à l'écran en jeu). */
    float shownProgress() {
        return shown;
    }

    static long nowMs() {
        return System.nanoTime() / 1_000_000L; // = Util.getMillis() du jeu
    }

    static float r(int c) {
        return ((c >> 16) & 0xFF) / 255F;
    }

    static float g(int c) {
        return ((c >> 8) & 0xFF) / 255F;
    }

    static float b(int c) {
        return (c & 0xFF) / 255F;
    }

    /** {@code ProcessHandle.pid} : la graine commune des astuces (la même pour la fenêtre précoce et pour le jeu). */
    static long tipSeed() {
        try {
            return ProcessHandle.current().pid();
        } catch (Throwable t) {
            return 0L;
        }
    }

    // ── la mise en page — IDENTIQUE à LoadingScreenArt.layout ──────────────────────────────────────────────────────────

    record Layout(int lx, int ly, int lw, int lh, int px, int py, int pw, int ph, boolean compact) {}

    static Layout layout(int w, int h) {
        int firstButton = h / 4 + 32;
        int room = firstButton - 8;
        int scale = (room >= LOGO_H * 2 && w >= LOGO_W * 2 + 20) ? 2 : 1;
        int lw = LOGO_W * scale, lh = LOGO_H * scale;
        int lx = (w - lw) / 2;
        int ly = Math.max(2, (firstButton - lh) / 2 - 1);
        int pw = Math.min(PANEL_MAX_W, w - 2 * SIDE);
        int px = (w - pw) / 2;
        int below = ly + lh;
        int avail = h - below;
        boolean compact = avail < OVER + PANEL_H + 2 * MIN_GAP;
        int ph = compact ? PANEL_H_COMPACT : PANEL_H;
        int gap = Math.max(MIN_GAP, (avail - OVER - ph) / 2);
        int py = below + gap + OVER;
        return new Layout(lx, ly, lw, lh, px, py, pw, ph, compact);
    }

    // ── l'image ─────────────────────────────────────────────────────────────────────────────────────────────────────────

    /** Dessine l'écran entier dans le cadre courant ({@code fbW × fbH} pixels). */
    void render(EarlyGl gl, int fbW, int fbH) {
        int s = options.guiScaleFor(fbW, fbH);
        int w = (int) Math.ceil((double) fbW / s), h = (int) Math.ceil((double) fbH / s);
        updateProgress();

        gl.begin2d(fbW, fbH);
        // fond : laque de nuit, panorama, voile (LoadingScreenArt.drawBackground)
        gl.quad(0, 0, 0, fbW, fbH, 0, 0, 0, 0, NIGHT, 1F);
        gl.flush2d();
        panorama.tick();
        float pa = panorama.fade();
        if (pa > 0F) panorama.render(gl, options.panoramaSpeed(), fbW, fbH, pa);
        gl.quad(0, 0, 0, fbW, fbH, 0, 0, 0, 0, VEIL, 1F);

        Layout l = layout(w, h);
        blit(gl, s, logo, l.lx, l.ly, l.lw, l.lh, 0, 0, logo.w, logo.h);
        drawPanel(gl, s, l);
        gl.end2d();
    }

    private void drawPanel(EarlyGl gl, int s, Layout l) {
        int px = l.px, py = l.py, pw = l.pw, ph = l.ph;
        fill(gl, s, px + 4, py + 5, px + pw + 4, py + ph + 5, SHADOW);
        if (seigaiha != null) {
            for (int ty = B; ty < ph - B; ty += BG_TILE) {
                int th = Math.min(BG_TILE, ph - B - ty);
                for (int tx = B; tx < pw - B; tx += BG_TILE) {
                    int tw = Math.min(BG_TILE, pw - B - tx);
                    blit(gl, s, seigaiha, px + tx, py + ty, tw, th, 0, 0, tw, th);
                }
            }
        }
        nine(gl, s, frame, px, py, pw, ph, FRAME_EDGE, FRAME_EDGE, FRAME_EDGE, FRAME_EDGE);

        String title = text.title;
        if (!title.isEmpty() && plaque != null) {
            int tw = ninja.width(title);
            int plw = Math.max(54, tw + 34);
            int plx = px + (pw - plw) / 2, ply = py - OVER;
            three(gl, s, plaque, plx - 1, ply - 1, plw + 2, 18);
            ninja.drawOutlined(gl, s, title, plx + (plw - tw) / 2, ply + 7, OUTLINE, 1F);
        }

        int x0 = px + B + PAD, x1 = px + pw - B - PAD;
        int pct = Math.max(0, Math.min(100, (int) Math.floor(shown * 100F)));
        String pctText = text.percent(pct);
        int pctW = pctText.isEmpty() ? 0 : ninja.width(pctText);
        int y1 = py + ROW1_Y;
        if (pctW > 0) ninja.drawOutlined(gl, s, pctText, x1 - pctW, y1, OUTLINE, 1F);
        int room = x1 - x0 - (pctW > 0 ? pctW + 8 : 0);
        String[] stage = stage();
        String counter = stage[1] == null ? "" : stage[1];
        int counterW = counter.isEmpty() ? 0 : body.width(counter) + 6;
        if (counterW > room / 2) {
            counter = "";
            counterW = 0;
        }
        String label = body.fit(stage[0] == null ? "" : stage[0], room - counterW);
        float after = body.draw(gl, s, label, x0, y1, TEXT, 1F);
        if (!counter.isEmpty()) body.draw(gl, s, counter, after + 6, y1, TEXT_SOFT, 1F);

        int by = py + BAR_Y, bw = x1 - x0;
        nine(gl, s, cell, x0 - 1, by - 1, bw + 2, BAR_H + 2, 6, 6, 6, 6);
        int fw = Math.round((bw - 4) * Math.max(0F, Math.min(1F, shown)));
        if (fw >= 6 && barFill != null) three(gl, s, barFill, x0 + 2, by + 2, fw, 3);

        if (l.compact) return;
        fill(gl, s, x0, py + SEP_Y, x1, py + SEP_Y + 1, SEP_DARK);
        fill(gl, s, x0, py + SEP_Y + 1, x1, py + SEP_Y + 2, SEP_LIGHT);
        if (text.tips.isEmpty()) return;
        if (!text.tipLabel.isEmpty()) ninja.drawOutlined(gl, s, text.tipLabel, x0, py + TIP_LABEL_Y, OUTLINE, 1F);
        long now = nowMs();
        String tip = text.tips.get(tipIndex(now, text.tips.size()));
        float ta = tipAlpha(now);
        List<String> lines = body.wrap(tip, x1 - x0, TIP_LINES);
        for (int i = 0; i < lines.size(); i++) body.draw(gl, s, lines.get(i), x0, py + TIP_Y + i * LINE_H, TEXT, ta);
    }

    /** L'astuce de l'instant {@code nowMs} — même calcul que l'écran en jeu. */
    static int tipIndex(long nowMs, int n) {
        return (int) Math.floorMod(Math.floorDiv(nowMs, TIP_MS) + tipSeed(), (long) n);
    }

    static float tipAlpha(long nowMs) {
        long t = Math.floorMod(nowMs, TIP_MS);
        float in = Math.min(1F, t / (float) TIP_FADE_MS);
        float out = Math.min(1F, (TIP_MS - t) / (float) TIP_FADE_MS);
        return Math.max(0F, Math.min(in, out));
    }

    // ── étape et progression (barres de StartupNotificationManager) ────────────────────────────────────────────────────

    /** {libellé, compteur} : la dernière barre CONNUE (étiquette de la barre EARLY ou nom de barre), comme l'écran en jeu. */
    private String[] stage() {
        String label = null, counter = null;
        try {
            for (ProgressMeter pm : StartupNotificationManager.getCurrentProgress()) {
                String key = "EARLY".equals(pm.name()) ? pm.label().getText() : pm.name();
                String l = text.stage(key);
                if (l == null) continue;
                label = l;
                counter = pm.steps() > 0 ? text.mods(Math.min(pm.current(), pm.steps()), pm.steps()) : null;
            }
        } catch (Throwable ignored) {
            // barres illisibles : on garde la dernière étape connue
        }
        if (label != null) lastStage = label;
        else if (lastStage == null) lastStage = text.stageStart;
        return new String[]{label != null ? label : lastStage, counter};
    }

    private void updateProgress() {
        float t = target;
        try {
            for (ProgressMeter pm : StartupNotificationManager.getCurrentProgress()) {
                String key = ("EARLY".equals(pm.name()) ? pm.label().getText() : pm.name()).toLowerCase(java.util.Locale.ROOT);
                for (Object[] m : MILESTONES) {
                    if (!key.startsWith((String) m[0])) continue;
                    float v = (Float) m[1];
                    if ("mod construction".equals(m[0]) && pm.steps() > 0) v += CONSTRUCTION_SPAN * Math.min(1F, pm.progress());
                    t = Math.max(t, v);
                }
            }
        } catch (Throwable ignored) {
            // rien
        }
        target = Math.min(PHASE_A_MAX, t);
        shown += (target - shown) * 0.12F;
    }

    // ── les pièces (miroir de LoadingPainter) ───────────────────────────────────────────────────────────────────────────

    private static void fill(EarlyGl gl, int s, int x0, int y0, int x1, int y1, int argb) {
        gl.quad(0, x0 * s, y0 * s, x1 * s, y1 * s, 0, 0, 0, 0, argb, 1F);
    }

    private static void blit(EarlyGl gl, int s, Tex t, float x, float y, float w, float h, float u, float v, float uw, float vh) {
        if (t == null || w <= 0 || h <= 0) return;
        gl.quad(t.id, x * s, y * s, (x + w) * s, (y + h) * s, u / t.w, v / t.h, (u + uw) / t.w, (v + vh) / t.h, 0xFFFFFFFF, 1F);
    }

    private static void nine(EarlyGl gl, int s, Tex t, int x, int y, int w, int h, int l, int r, int top, int bot) {
        if (t == null) return;
        int tw = t.w, th = t.h;
        int mw = Math.max(0, w - l - r), mh = Math.max(0, h - top - bot);
        int cw = tw - l - r, ch = th - top - bot;
        blit(gl, s, t, x, y, l, top, 0, 0, l, top);
        blit(gl, s, t, x + w - r, y, r, top, tw - r, 0, r, top);
        blit(gl, s, t, x, y + h - bot, l, bot, 0, th - bot, l, bot);
        blit(gl, s, t, x + w - r, y + h - bot, r, bot, tw - r, th - bot, r, bot);
        if (mw > 0) {
            blit(gl, s, t, x + l, y, mw, top, l, 0, cw, top);
            blit(gl, s, t, x + l, y + h - bot, mw, bot, l, th - bot, cw, bot);
        }
        if (mh > 0) {
            blit(gl, s, t, x, y + top, l, mh, 0, top, l, ch);
            blit(gl, s, t, x + w - r, y + top, r, mh, tw - r, top, r, ch);
        }
        if (mw > 0 && mh > 0) blit(gl, s, t, x + l, y + top, mw, mh, l, top, cw, ch);
    }

    private static void three(EarlyGl gl, int s, Tex t, int x, int y, int w, int cap) {
        if (t == null) return;
        int tw = t.w, th = t.h;
        int mw = Math.max(0, w - 2 * cap);
        blit(gl, s, t, x, y, cap, th, 0, 0, cap, th);
        blit(gl, s, t, x + w - cap, y, cap, th, tw - cap, 0, cap, th);
        if (mw > 0) blit(gl, s, t, x + cap, y, mw, th, cap, 0, tw - 2 * cap, th);
    }

    @Override
    public void close() {
        for (Tex t : new Tex[]{frame, seigaiha, plaque, cell, barFill, logo}) if (t != null) EarlyGl.delete(t.id);
        ninja.close();
        body.close();
        panorama.close();
    }
}
