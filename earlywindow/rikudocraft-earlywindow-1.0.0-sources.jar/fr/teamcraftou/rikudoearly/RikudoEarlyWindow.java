/*
 * Copyright (c) Forge Development LLC and contributors
 * Copyright (c) 2026 Team Craftou (modifications : écran RikudoCraft, repli sur la fenêtre de FML)
 * SPDX-License-Identifier: LGPL-2.1-only
 *
 * Dérivé de net.neoforged.fml.earlydisplay.DisplayWindow (FancyModLoader 4.0.41 / 4.0.42, LGPL-2.1-only). Création de la
 * fenêtre, boucle du fil de rendu et passation à Minecraft reprises de FML ; seul le DESSIN change. Voir README.md.
 */
package fr.teamcraftou.rikudoearly;

import static org.lwjgl.glfw.GLFW.*;
import static org.lwjgl.opengl.GL32C.*;

import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.Objects;
import java.util.Optional;
import java.util.StringJoiner;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;
import java.util.function.LongSupplier;
import java.util.function.Supplier;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import joptsimple.OptionParser;
import net.neoforged.fml.earlydisplay.ColourScheme;
import net.neoforged.fml.earlydisplay.DisplayWindow;
import net.neoforged.fml.earlydisplay.RenderElement;
import net.neoforged.fml.earlydisplay.STBHelper;
import net.neoforged.fml.loading.FMLConfig;
import net.neoforged.fml.loading.FMLPaths;
import net.neoforged.fml.loading.ImmediateWindowHandler;
import net.neoforged.fml.loading.progress.StartupNotificationManager;
import org.jetbrains.annotations.Nullable;
import org.lwjgl.PointerBuffer;
import org.lwjgl.system.Callback;
import org.lwjgl.glfw.GLFWImage;
import org.lwjgl.glfw.GLFWVidMode;
import org.lwjgl.opengl.GL;
import org.lwjgl.opengl.GLCapabilities;
import org.lwjgl.stb.STBImage;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * <h2>⚠⚠ 11-18e — LA FENÊTRE PRÉCOCE RIKUDOCRAFT (fournisseur « rikudocraft »)</h2>
 *
 * <p>Designer : « refais ce menu-là aussi de NeoForge [la fenêtre rouge au renard], genre avec le launcher ou le mod, mais il
 * doit être refait ». Ce jar SÉPARÉ (pas un mod : couche SERVICE de FML, déclaré par
 * {@code META-INF/services/net.neoforged.neoforgespi.earlywindow.ImmediateWindowProvider}) est posé dans {@code mods/} par
 * le launcher, qui écrit {@code earlyWindowProvider = "rikudocraft"} dans {@code config/fml.toml}. Il dessine l'écran de
 * chargement RikudoCraft dès le clic sur JOUER — au pixel près celui que le mod reprend ensuite en jeu
 * ({@code client/loading/RikudoLoadingOverlay}) : le passage de relais ne se voit pas.</p>
 *
 * <h3>Sûreté (le démarrage de TOUS les joueurs passe par ici)</h3>
 * <ul>
 *   <li>Classe FILLE de {@link DisplayWindow} : si notre {@link #initialize} échoue (mod introuvable, texture, shader,
 *       fenêtre…), on nettoie et on appelle {@code super.initialize} — la VRAIE fenêtre de FML prend tout en charge, et
 *       chaque méthode surchargée lui délègue ({@link #delegate}). {@code -Drikudocraft.earlywindow.off=true} force ce repli.</li>
 *   <li>Création de la fenêtre, fil de rendu, passation ({@link #setupMinecraftWindow}) : la logique de FML, recopiée ;
 *       {@code loadingOverlay} et {@code updateModuleReads} sont ceux de FML (non surchargés) : le jeu reçoit le
 *       {@code NeoForgeLoadingOverlay} habituel, avec CETTE fenêtre — que le mod remplace par son écran.</li>
 *   <li>Toute exception du DESSIN est attrapée : on n'écrit plus qu'un fond uni, jamais de plantage. Après la passation, on
 *       dessine au milieu de l'initialisation du jeu : l'état GL touché est relevé puis rendu ({@code EarlyGl.Snapshot}).</li>
 *   <li>Dès que le jeu crée son écran de chargement, on ne dessine plus rien (pas de double rendu sur la même fenêtre).</li>
 * </ul>
 */
public class RikudoEarlyWindow extends DisplayWindow {

    /** Le nom à écrire dans {@code config/fml.toml} → {@code earlyWindowProvider}. */
    public static final String NAME = "rikudocraft";
    /** Propriétés lues par l'écran de chargement du mod au passage de relais. */
    public static final String PROP_ACTIVE = "rikudocraft.earlywindow.active", PROP_PROGRESS = "rikudocraft.earlywindow.progress";

    private static final Logger LOGGER = LoggerFactory.getLogger("RIKUDO-EARLYDISPLAY");
    // les mêmes profils que DisplayWindow.GL_VERSIONS
    private static final int[][] GL_VERSIONS = {{4, 6}, {4, 5}, {4, 4}, {4, 3}, {4, 2}, {4, 1}, {4, 0}, {3, 3}, {3, 2}};
    private static final long MIN_FRAME_NS = TimeUnit.MILLISECONDS.toNanos(10);
    private static final long MAIN_FRAME_NS = TimeUnit.MILLISECONDS.toNanos(33);

    /** Vrai = la fenêtre de FML (classe mère) fait tout. */
    private volatile boolean delegate;

    private final Semaphore lock = new Semaphore(1);
    private ScheduledExecutorService scheduler;
    private volatile ScheduledFuture<?> windowTick;
    private volatile Runnable repaint = () -> {};
    /**
     * Vrai jusqu'à la passation : le fil de rendu rend le contexte GL après chaque image. (FML teste {@code windowTick != null},
     * affecté SUR son fil de rendu ; ici la tâche est programmée depuis le fil principal : un drapeau à part évite la course
     * avec la première image.)
     */
    private volatile boolean renderThreadOwnsContext = true;
    private long window;
    private GLCapabilities caps;
    private int fbWidth;
    private int fbHeight;
    private int winWidth;
    private int winHeight;
    private int winX;
    private int winY;
    private boolean maximized;
    private String glVersion;
    private boolean swapIntervalSet;
    private long nextFrameNs;

    private EarlyAssets assets;
    private EarlyAssets.Options options;
    private EarlyGl gl;
    private EarlyScreen screen;
    private volatile boolean drawBroken;
    private volatile boolean handedOver;
    private volatile boolean closed;

    @Override
    public String name() {
        return NAME;
    }

    // ── démarrage ───────────────────────────────────────────────────────────────────────────────────────────────────────

    @Override
    public Runnable initialize(String[] arguments) {
        if (Boolean.getBoolean("rikudocraft.earlywindow.off")) {
            LOGGER.info("Fenêtre précoce RikudoCraft coupée (-Drikudocraft.earlywindow.off) : fenêtre de NeoForge");
            delegate = true;
            return super.initialize(arguments);
        }
        try {
            return rkInitialize(arguments);
        } catch (Throwable t) {
            LOGGER.error("Fenêtre précoce RikudoCraft indisponible, repli sur celle de NeoForge", t);
            rkAbort();
            delegate = true;
            return super.initialize(arguments);
        }
    }

    private Runnable rkInitialize(String[] arguments) throws Exception {
        // ── comme DisplayWindow.initialize ──
        final OptionParser parser = new OptionParser();
        var mcversionopt = parser.accepts("fml.mcVersion").withRequiredArg().ofType(String.class);
        var forgeversionopt = parser.accepts("fml.neoForgeVersion").withRequiredArg().ofType(String.class);
        var neoformopt = parser.accepts("fml.neoFormVersion").withRequiredArg().ofType(String.class);
        var widthopt = parser.accepts("width").withRequiredArg().ofType(Integer.class)
                .defaultsTo(FMLConfig.getIntConfigValue(FMLConfig.ConfigValue.EARLY_WINDOW_WIDTH));
        var heightopt = parser.accepts("height").withRequiredArg().ofType(Integer.class)
                .defaultsTo(FMLConfig.getIntConfigValue(FMLConfig.ConfigValue.EARLY_WINDOW_HEIGHT));
        var maximizedopt = parser.accepts("earlywindow.maximized");
        parser.allowsUnrecognizedOptions();
        var parsed = parser.parse(arguments);
        winWidth = parsed.valueOf(widthopt);
        winHeight = parsed.valueOf(heightopt);
        maximized = parsed.has(maximizedopt) || FMLConfig.getBoolConfigValue(FMLConfig.ConfigValue.EARLY_WINDOW_MAXIMIZED);
        String mcVersion = parsed.valueOf(mcversionopt);
        String forgeVersion = parsed.valueOf(forgeversionopt);
        String neoFormVersion = parsed.valueOf(neoformopt);

        // ── nos fichiers : le jar du mod (et la police du jeu) — introuvable → repli sur FML ──
        options = EarlyAssets.Options.read(FMLPaths.GAMEDIR.get());
        assets = EarlyAssets.locate(FMLPaths.GAMEDIR.get(), FMLPaths.MODSDIR.get(), mcVersion, neoFormVersion);
        LOGGER.info("Fenêtre précoce RikudoCraft : textures lues dans {}{}", assets.modDescription,
                assets.hasGameFont() ? "" : " (police du jeu introuvable : texte courant omis)");

        FMLConfig.updateConfig(FMLConfig.ConfigValue.EARLY_WINDOW_WIDTH, winWidth);
        FMLConfig.updateConfig(FMLConfig.ConfigValue.EARLY_WINDOW_HEIGHT, winHeight);
        StartupNotificationManager.modLoaderConsumer().ifPresent(c -> c.accept("NeoForge loading " + forgeVersion));

        // ── comme DisplayWindow.start ──
        scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
            final var thread = Executors.defaultThreadFactory().newThread(r);
            thread.setDaemon(true);
            thread.setName("RikudoCraft early window");
            return thread;
        });
        rkInitWindow(mcVersion);

        // ── GL : sur ce fil, AVANT d'afficher la fenêtre (une erreur ici retombe encore proprement sur FML) ──
        glfwMakeContextCurrent(window);
        caps = GL.createCapabilities();
        LOGGER.info("GL info: " + glGetString(GL_RENDERER) + " GL version " + glGetString(GL_VERSION) + ", " + glGetString(GL_VENDOR));
        gl = new EarlyGl();
        gl.init();
        screen = new EarlyScreen(assets, options);
        drawFrame(); // la première image existe avant que la fenêtre apparaisse
        if (drawBroken) throw new IllegalStateException("première image impossible (voir l'erreur ci-dessus)");
        glfwMakeContextCurrent(0);

        // ── fin de DisplayWindow.initWindow : afficher, relever la position et la taille ──
        glfwShowWindow(window);
        int[] x = new int[1];
        int[] y = new int[1];
        glfwGetWindowPos(window, x, y);
        handleLastGLFWError((error, description) -> LOGGER.debug(String.format("Suppressing GLFW get window position error: [0x%X]%s", error, description)));
        winX = x[0];
        winY = y[0];
        glfwGetFramebufferSize(window, x, y);
        fbWidth = x[0];
        fbHeight = y[0];
        glfwPollEvents();

        // ── le fil de rendu (DisplayWindow.initRender : 20 i/s chez FML, 30 ici pour le balancement du panorama) ──
        windowTick = scheduler.scheduleAtFixedRate(this::rkRenderThreadFunc, 33, 33, TimeUnit.MILLISECONDS);
        return this::periodicTick;
    }

    /** Après un échec de notre démarrage : tout ce qui a été créé est rendu, la fenêtre détruite (FML créera la sienne). */
    private void rkAbort() {
        try {
            if (scheduler != null) scheduler.shutdownNow();
        } catch (Throwable ignored) {
            // rien
        }
        if (window != 0L) {
            try {
                glfwMakeContextCurrent(window);
                if (caps != null) GL.setCapabilities(caps);
                if (screen != null) screen.close();
                if (gl != null) gl.close();
            } catch (Throwable ignored) {
                // le contexte disparaît avec la fenêtre
            }
            try {
                glfwMakeContextCurrent(0);
                freeCallback(glfwSetFramebufferSizeCallback(window, null));
                freeCallback(glfwSetWindowPosCallback(window, null));
                freeCallback(glfwSetWindowSizeCallback(window, null));
                glfwDestroyWindow(window);
            } catch (Throwable ignored) {
                // rien
            }
        }
        try {
            if (assets != null) assets.close();
        } catch (Throwable ignored) {
            // rien
        }
        window = 0L;
        screen = null;
        gl = null;
        assets = null;
        scheduler = null;
        windowTick = null;
    }

    /**
     * {@code DisplayWindow.initWindow}, à l'identique sauf : titre RikudoCraft, icône du mod, fenêtre encore CACHÉE au retour,
     * et une exception (au lieu de la boîte d'erreur) pour que {@link #initialize} rende la main à la fenêtre de FML.
     */
    private void rkInitWindow(@Nullable String mcVersion) {
        long glfwInitBegin = System.nanoTime();
        if (!glfwInit()) throw new IllegalStateException("Unable to initialize GLFW");
        long glfwInitEnd = System.nanoTime();
        if (glfwInitEnd - glfwInitBegin > 1e9) {
            LOGGER.error("WARNING : glfwInit took {} seconds to start.", (glfwInitEnd - glfwInitBegin) / 1.0e9);
        }
        handleLastGLFWError((error, description) -> LOGGER.error(String.format("Suppressing Last GLFW error: [0x%X]%s", error, description)));

        glfwDefaultWindowHints();
        glfwWindowHint(GLFW_CLIENT_API, GLFW_OPENGL_API);
        glfwWindowHint(GLFW_CONTEXT_CREATION_API, GLFW_NATIVE_CONTEXT_API);
        glfwWindowHint(GLFW_VISIBLE, GLFW_FALSE);
        glfwWindowHint(GLFW_RESIZABLE, GLFW_TRUE);
        if (mcVersion != null) {
            String vanillaWindowTitle = "Minecraft* " + mcVersion;
            glfwWindowHintString(GLFW_X11_CLASS_NAME, vanillaWindowTitle);
            glfwWindowHintString(GLFW_X11_INSTANCE_NAME, vanillaWindowTitle);
        }
        long primaryMonitor = glfwGetPrimaryMonitor();
        if (primaryMonitor == 0) throw new IllegalStateException("Can't find a primary monitor");
        GLFWVidMode vidmode = glfwGetVideoMode(primaryMonitor);
        if (vidmode == null) throw new IllegalStateException("Can't get a resolution");

        long win = 0;
        var successfulWindow = new AtomicBoolean(false);
        var windowFailFuture = scheduler.schedule(() -> {
            if (!successfulWindow.get()) crash("Timed out trying to setup the Game Window.");
        }, 30, TimeUnit.SECONDS);
        int versidx = 0;
        var skipVersions = FMLConfig.<String>getListConfigValue(FMLConfig.ConfigValue.EARLY_WINDOW_SKIP_GL_VERSIONS);
        final String[] lastGLError = new String[GL_VERSIONS.length];
        do {
            final var glVersionToTry = GL_VERSIONS[versidx][0] + "." + GL_VERSIONS[versidx][1];
            if (skipVersions.contains(glVersionToTry)) {
                LOGGER.info("Skipping GL version " + glVersionToTry + " because of configuration");
                versidx++;
                continue;
            }
            LOGGER.info("Trying GL version " + glVersionToTry);
            glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, GL_VERSIONS[versidx][0]);
            glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, GL_VERSIONS[versidx][1]);
            glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
            glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
            win = glfwCreateWindow(winWidth, winHeight, "RikudoCraft", 0L, 0L);
            var erridx = versidx;
            handleLastGLFWError((error, description) -> lastGLError[erridx] = String.format("Trying %d.%d: GLFW error: [0x%X]%s", GL_VERSIONS[erridx][0], GL_VERSIONS[erridx][1], error, description));
            if (lastGLError[versidx] != null) LOGGER.trace(lastGLError[versidx]);
            versidx++;
        } while (win == 0 && versidx < GL_VERSIONS.length);
        if (versidx == GL_VERSIONS.length && win == 0) {
            windowFailFuture.cancel(false);
            throw new IllegalStateException("Failed to find a valid GLFW profile. We tried "
                    + Arrays.stream(GL_VERSIONS).map(p -> p[0] + "." + p[1]).filter(o -> !skipVersions.contains(o))
                            .collect(Collector.of(() -> new StringJoiner(", ").setEmptyValue("no versions"), StringJoiner::add, StringJoiner::merge, StringJoiner::toString))
                    + ". " + Arrays.stream(lastGLError).filter(Objects::nonNull).collect(Collectors.joining(" ")));
        }
        successfulWindow.set(true);
        windowFailFuture.cancel(false);
        var requestedVersion = GL_VERSIONS[versidx - 1][0] + "." + GL_VERSIONS[versidx - 1][1];
        var maj = glfwGetWindowAttrib(win, GLFW_CONTEXT_VERSION_MAJOR);
        var min = glfwGetWindowAttrib(win, GLFW_CONTEXT_VERSION_MINOR);
        var gotVersion = maj + "." + min;
        LOGGER.info("Requested GL version " + requestedVersion + " got version " + gotVersion);
        this.glVersion = gotVersion;
        this.window = win;

        int[] x = new int[1];
        int[] y = new int[1];
        glfwGetMonitorPos(primaryMonitor, x, y);
        int monitorX = x[0];
        int monitorY = y[0];
        if (this.maximized) glfwMaximizeWindow(win);
        glfwGetWindowSize(win, x, y);
        this.winWidth = x[0];
        this.winHeight = y[0];
        glfwSetWindowPos(win, (vidmode.width() - this.winWidth) / 2 + monitorX, (vidmode.height() - this.winHeight) / 2 + monitorY);
        setIcon(win);
        handleLastGLFWError((error, description) -> LOGGER.debug(String.format("Suppressing GLFW icon error: [0x%X]%s", error, description)));

        glfwSetFramebufferSizeCallback(win, this::fbResize);
        glfwSetWindowPosCallback(win, this::winMove);
        glfwSetWindowSizeCallback(win, this::winResize);
        glfwGetFramebufferSize(win, x, y);
        this.fbWidth = x[0];
        this.fbHeight = y[0];
    }

    /** L'icône : le logo du mod (logoFile de neoforge.mods.toml), sinon celle de FML. Jamais bloquant. */
    private void setIcon(long win) {
        int[] w = new int[1];
        int[] h = new int[1];
        int[] c = new int[1];
        ByteBuffer img = null;
        ByteBuffer src = null;
        try {
            byte[] png = assets.readModRoot("teamcraftouiconbigresolution.png");
            if (png != null) {
                src = MemoryUtil.memAlloc(png.length);
                src.put(png).flip();
                img = STBImage.stbi_load_from_memory(src, w, h, c, 4);
            }
            if (img == null) img = STBHelper.loadImageFromClasspath("neoforged_icon.png", 20000, w, h, c);
            if (img == null) return;
            try (var buf = GLFWImage.create(MemoryUtil.getAllocator().malloc(GLFWImage.SIZEOF), 1); GLFWImage one = GLFWImage.malloc()) {
                buf.put(one.set(w[0], h[0], img));
                buf.flip();
                glfwSetWindowIcon(win, buf);
            }
        } catch (Throwable t) {
            LOGGER.debug("Icône de la fenêtre précoce non posée", t);
        } finally {
            if (img != null) STBImage.stbi_image_free(img);
            if (src != null) MemoryUtil.memFree(src);
        }
    }

    private void winResize(long win, int width, int height) {
        if (win == this.window && width != 0 && height != 0) {
            this.winWidth = width;
            this.winHeight = height;
        }
    }

    private void fbResize(long win, int width, int height) {
        if (win == this.window && width != 0 && height != 0) {
            this.fbWidth = width;
            this.fbHeight = height;
        }
    }

    private void winMove(long win, int x, int y) {
        if (win == this.window) {
            this.winX = x;
            this.winY = y;
        }
    }

    private static void handleLastGLFWError(BiConsumer<Integer, String> handler) {
        try (MemoryStack memorystack = MemoryStack.stackPush()) {
            PointerBuffer pointerbuffer = memorystack.mallocPointer(1);
            int error = glfwGetError(pointerbuffer);
            if (error != GLFW_NO_ERROR) {
                long pDescription = pointerbuffer.get();
                String description = pDescription == 0L ? "" : MemoryUtil.memUTF8(pDescription);
                handler.accept(error, description);
            }
        }
    }

    private static void freeCallback(Callback cb) {
        if (cb != null) cb.free();
    }

    // ── le dessin ───────────────────────────────────────────────────────────────────────────────────────────────────────

    /**
     * Une image : l'écran dans le cadre hors écran, recopié vers la fenêtre, puis échange des tampons. Une exception arrête
     * le dessin pour de bon : il ne reste qu'un fond uni (jamais de plantage).
     */
    private void drawFrame() {
        int w = fbWidth, h = fbHeight;
        if (w <= 0 || h <= 0 || closed) return;
        if (!drawBroken) {
            try {
                gl.bindFramebuffer(w, h);
                screen.render(gl, w, h);
                gl.presentToWindow(w, h);
                if (assets != null && screen.panoramaFinished()) { // tout est chargé : le jar du mod est rendu à FML
                    assets.close();
                    assets = null;
                }
            } catch (Throwable t) {
                drawBroken = true;
                LOGGER.error("Fenêtre précoce RikudoCraft : dessin arrêté (fond uni jusqu'au jeu)", t);
            }
        }
        if (drawBroken) {
            try {
                glBindFramebuffer(GL_FRAMEBUFFER, 0);
                glViewport(0, 0, w, h);
                glClearColor(EarlyScreen.r(EarlyScreen.NIGHT), EarlyScreen.g(EarlyScreen.NIGHT), EarlyScreen.b(EarlyScreen.NIGHT), 1F);
                glClear(GL_COLOR_BUFFER_BIT);
            } catch (Throwable ignored) {
                // rien
            }
        }
        glfwSwapBuffers(window);
    }

    /** {@code DisplayWindow.renderThreadFunc} : le fil de rendu tient le contexte le temps d'une image. */
    private void rkRenderThreadFunc() {
        if (!lock.tryAcquire()) return;
        try {
            if (!renderThreadOwnsContext || closed) return;
            long nt = System.nanoTime();
            if (nt < nextFrameNs) return;
            nextFrameNs = nt + MIN_FRAME_NS;
            glfwMakeContextCurrent(window);
            GL.setCapabilities(caps);
            if (!swapIntervalSet) {
                glfwSwapInterval(1);
                swapIntervalSet = true;
            }
            drawFrame();
        } catch (Throwable t) {
            LOGGER.error("BARF", t);
        } finally {
            if (renderThreadOwnsContext) glfwMakeContextCurrent(0);
            lock.release();
        }
    }

    /**
     * Après la passation, sur le fil PRINCIPAL (appelé par {@link #periodicTick} pendant la construction des mods) : comme FML,
     * mais l'état GL que l'on touche est relevé puis rendu — Minecraft a déjà initialisé son rendu.
     */
    private void rkRepaintOnMain() {
        if (handedOver || closed) return;
        long nt = System.nanoTime();
        if (nt < nextFrameNs) return;
        nextFrameNs = nt + MAIN_FRAME_NS;
        EarlyGl.Snapshot snap = null;
        try {
            snap = new EarlyGl.Snapshot();
            int[] x = new int[1];
            int[] y = new int[1];
            glfwGetFramebufferSize(window, x, y);
            if (x[0] > 0 && y[0] > 0) {
                fbWidth = x[0];
                fbHeight = y[0];
            }
            drawFrame();
        } catch (Throwable t) {
            drawBroken = true;
            LOGGER.error("Fenêtre précoce RikudoCraft : dessin arrêté", t);
        } finally {
            if (snap != null) {
                try {
                    snap.restore();
                } catch (Throwable ignored) {
                    // rien
                }
            }
        }
    }

    // ── l'API de la fenêtre précoce (chaque méthode : notre version, ou celle de FML en repli) ───────────────────────────

    @Override
    public void periodicTick() {
        if (delegate) {
            super.periodicTick();
            return;
        }
        glfwPollEvents();
        repaint.run();
    }

    @Override
    public String getGLVersion() {
        return delegate ? super.getGLVersion() : this.glVersion;
    }

    /** {@code DisplayWindow.setupMinecraftWindow}, à l'identique (sans l'attente d'une initialisation déjà faite). */
    @Override
    public long setupMinecraftWindow(final IntSupplier width, final IntSupplier height, final Supplier<String> title, final LongSupplier monitorSupplier) {
        if (delegate) return super.setupMinecraftWindow(width, height, title, monitorSupplier);
        ImmediateWindowHandler.updateProgress("Initializing Game Graphics");
        while (!this.windowTick.isDone()) {
            this.windowTick.cancel(false);
        }
        var tries = 0;
        var renderlockticket = false;
        do {
            try {
                renderlockticket = lock.tryAcquire(100, TimeUnit.MILLISECONDS);
                if (++tries > 9) {
                    Thread.dumpStack();
                    crash("We seem to be having trouble handing off the window, tried for 1 second");
                }
            } catch (InterruptedException e) {
                Thread.interrupted();
            }
        } while (!renderlockticket);
        renderThreadOwnsContext = false; // plus aucune image du fil de rendu : le contexte passe au fil principal
        lock.release();

        glfwMakeContextCurrent(window);
        glfwSetWindowTitle(window, title.get());
        glfwSwapInterval(0);
        freeCallback(glfwSetFramebufferSizeCallback(window, null));
        freeCallback(glfwSetWindowPosCallback(window, null));
        freeCallback(glfwSetWindowSizeCallback(window, null));
        this.repaint = this::rkRepaintOnMain;
        this.windowTick = null;
        return window;
    }

    @Override
    public boolean positionWindow(final Optional<Object> monitor, final IntConsumer widthSetter, final IntConsumer heightSetter, final IntConsumer xSetter, final IntConsumer ySetter) {
        if (delegate) return super.positionWindow(monitor, widthSetter, heightSetter, xSetter, ySetter);
        widthSetter.accept(this.winWidth);
        heightSetter.accept(this.winHeight);
        xSetter.accept(this.winX);
        ySetter.accept(this.winY);
        return true;
    }

    @Override
    public void updateFramebufferSize(final IntConsumer width, final IntConsumer height) {
        if (delegate) {
            super.updateFramebufferSize(width, height);
            return;
        }
        width.accept(this.fbWidth);
        height.accept(this.fbHeight);
    }

    /**
     * Le jeu crée son écran de chargement : on cesse de dessiner, et on laisse à l'écran du mod l'avancement atteint (sa barre
     * repart de là). L'écran lui-même est celui de FML (méthode mère) : {@code NeoForgeLoadingOverlay} avec CETTE fenêtre.
     */
    @Override
    public <T> Supplier<T> loadingOverlay(final Supplier<?> mc, final Supplier<?> ri, final Consumer<Optional<Throwable>> ex, final boolean fade) {
        if (!delegate) {
            handedOver = true;
            try {
                System.setProperty(PROP_ACTIVE, drawBroken ? "false" : "true");
                System.setProperty(PROP_PROGRESS, Float.toString(screen == null ? 0F : screen.shownProgress()));
            } catch (Throwable ignored) {
                // l'écran du mod repartira de zéro
            }
        }
        return super.loadingOverlay(mc, ri, ex, fade);
    }

    /** Appelé par {@code NeoForgeLoadingOverlay} (si l'écran du mod ne le remplace pas) : notre image dans le cadre. */
    @Override
    public void render(int alpha) {
        if (delegate) {
            super.render(alpha);
            return;
        }
        if (closed || drawBroken || gl == null || screen == null) return;
        EarlyGl.Snapshot snap = null;
        try {
            snap = new EarlyGl.Snapshot();
            int[] x = new int[1];
            int[] y = new int[1];
            glfwGetFramebufferSize(window, x, y);
            if (x[0] > 0 && y[0] > 0) {
                gl.bindFramebuffer(x[0], y[0]);
                screen.render(gl, x[0], y[0]);
            }
        } catch (Throwable t) {
            drawBroken = true;
            LOGGER.error("Fenêtre précoce RikudoCraft : dessin arrêté", t);
        } finally {
            if (snap != null) {
                try {
                    snap.restore();
                } catch (Throwable ignored) {
                    // rien
                }
            }
        }
    }

    @Override
    public int getFramebufferTextureId() {
        if (delegate) return super.getFramebufferTextureId();
        return gl == null ? 0 : gl.framebufferTexture();
    }

    /** Taille du cadre (échelle 1) : {@code NeoForgeLoadingOverlay} le pose alors exactement sur la fenêtre. */
    @Override
    public RenderElement.DisplayContext context() {
        if (delegate) return super.context();
        int w = gl == null ? 0 : gl.framebufferWidth(), h = gl == null ? 0 : gl.framebufferHeight();
        return new RenderElement.DisplayContext(Math.max(1, w > 0 ? w : fbWidth), Math.max(1, h > 0 ? h : fbHeight), 1, null,
                ColourScheme.BLACK, null);
    }

    @Override
    public void addMojangTexture(final int textureId) {
        if (delegate) super.addMojangTexture(textureId);
        // sinon : pas de logo Mojang sur l'écran RikudoCraft
    }

    /** Fin du chargement (fil du rendu du jeu, contexte courant) : fil, cadre, shaders, textures. */
    @Override
    public void close() {
        if (delegate) {
            super.close();
            return;
        }
        if (closed) return;
        closed = true;
        handedOver = true;
        try {
            if (scheduler != null) scheduler.shutdown();
        } catch (Throwable ignored) {
            // rien
        }
        try {
            if (screen != null) screen.close();
        } catch (Throwable ignored) {
            // rien
        }
        try {
            if (gl != null) gl.close();
        } catch (Throwable ignored) {
            // rien
        }
        try {
            if (assets != null) assets.close();
        } catch (Throwable ignored) {
            // rien
        }
        screen = null;
        gl = null;
        assets = null;
    }
}
